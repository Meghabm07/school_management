-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2019 at 03:51 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `phonenumber` int(10) NOT NULL,
  `presentadd` varchar(1000) NOT NULL,
  `permanentadd` varchar(1000) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `bloodgroup` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `dob` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `joiningdate` timestamp(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000',
  `description` mediumtext NOT NULL,
  `file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `uname`, `pw`, `phonenumber`, `presentadd`, `permanentadd`, `designation`, `gender`, `bloodgroup`, `religion`, `dob`, `joiningdate`, `description`, `file`) VALUES
(10, 'meghabm07@gmail.com', 'Megha', '202cb962ac59075b964b07152d234b70', 2147483647, '#64 Main road cubbenpet bangalore', '#64 Main road cubbenpet bangalore', 'Head Master', 'Female', 'O+', 'Hindhu', '2018-12-05 18:30:00.000000', '2018-12-05 18:30:00.000000', 'Cardiology is a branch of medicine dealing with disorders of the heart as well as parts of the circulatory system. The field includes medical diagnosis and treatment of congenital heart defects, coronary artery disease, heart failure, valvular heart disease and electrophysiology', '11.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `classname` varchar(25) NOT NULL,
  `monthlyfee` varchar(10) NOT NULL,
  `admissionfee` varchar(10) NOT NULL,
  `examfee` varchar(10) NOT NULL,
  `certificationfee` varchar(10) NOT NULL,
  `duedate` varchar(1000) NOT NULL,
  `note` varchar(10) NOT NULL,
  `created_at` varchar(10) NOT NULL,
  `modified_at` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`classname`, `monthlyfee`, `admissionfee`, `examfee`, `certificationfee`, `duedate`, `note`, `created_at`, `modified_at`) VALUES
('One', '12', '123', '123', '123', '2019-01-04', '', '2018-12-31', '2018-12-31'),
('Three', '123123', '1231', '23112222', '213', '2019-01-12', 'df', '2019-01-02', ''),
('Two', '325', '22', '322', '22', '2019-01-05', 'dxfcgvhjk', '2018-12-31', '');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `section` varchar(100) NOT NULL,
  `classname` varchar(20) NOT NULL,
  `teachername` varchar(20) NOT NULL,
  `description` varchar(20) NOT NULL,
  `created_at` varchar(100) NOT NULL,
  `modified_at` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`section`, `classname`, `teachername`, `description`, `created_at`, `modified_at`) VALUES
('B', 'One', 'Nisha', 'sdaf', '2018-12-31 06:17:23', ''),
('A', 'Two', 'Nisha', 'dsafdg', '2018-12-31 06:17:33', ''),
('A', 'One', 'Nisha', 'fsdg', '2018-12-31 06:22:44', ''),
('B', 'Three', 'Nisha', '', '2019-01-02 05:53:34', '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `rollno` int(225) NOT NULL,
  `studentname` varchar(20) NOT NULL,
  `parentname` varchar(20) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `phonenumber` varchar(20) NOT NULL,
  `presentadd` varchar(100) NOT NULL,
  `permanentadd` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `studentemail` varchar(100) NOT NULL,
  `parentemail` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `studentpassword` varchar(100) NOT NULL,
  `parentpassword` varchar(100) NOT NULL,
  `bloodgroup` varchar(100) NOT NULL,
  `admissiondate` varchar(100) NOT NULL,
  `classname` varchar(20) NOT NULL,
  `section` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  `created_at` varchar(100) NOT NULL,
  `modified_at` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`rollno`, `studentname`, `parentname`, `dob`, `gender`, `phonenumber`, `presentadd`, `permanentadd`, `religion`, `studentemail`, `parentemail`, `file`, `studentpassword`, `parentpassword`, `bloodgroup`, `admissiondate`, `classname`, `section`, `description`, `created_at`, `modified_at`) VALUES
(2, 'Madhu', 'mahadev', '2011-03-03', 'Female', '9343759642', '#64 Main road cubbenpet bangalore', '#64 Main road cubbenpet bangalore', 'Hindhu', 'madhu@gmail.com', 'hj@h.hjk', '22.jpg', '123', '123', 'O+', '2019-01-03', 'One ', 'A', 'xdfcgvhbjnk', '2018-12-31 06:58:27', ''),
(3, 'nayana', 'naya', '1997-08-06', 'Female', 'hindhu', '#64 Main road cubbenpet bangalore', '#64 Main road cubbenpet bangalore', 'hindhu', 'g@g.g', 'g@g.g', '11.jpg', '1234', '123', 'O+', '2018-12-22', 'One ', 'A', 'wertyu wertfyhui erdtfyuhi ertfyuhij sdrftgyhuj rtfyuhi sdrtfyhuij drtfyuhj rtfyuhj sdrftgyhj rtfyuh', '2018-12-31 07:56:56', '');

-- --------------------------------------------------------

--
-- Table structure for table `students_attendence`
--

CREATE TABLE `students_attendence` (
  `rollno` int(255) NOT NULL,
  `studentname` varchar(100) NOT NULL,
  `parentname` varchar(100) NOT NULL,
  `classname` varchar(100) NOT NULL,
  `sectionname` varchar(100) NOT NULL,
  `attendencedate` varchar(1000) NOT NULL,
  `present` varchar(100) NOT NULL,
  `absent` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students_attendence`
--

INSERT INTO `students_attendence` (`rollno`, `studentname`, `parentname`, `classname`, `sectionname`, `attendencedate`, `present`, `absent`) VALUES
(1, 'Megha', 'Mohan', 'One ', 'A', '2018-12-11', 'P', '0'),
(1, 'Megha', 'Mohan', 'One ', 'A', '2018-12-12', '0', 'A'),
(1, 'Megha', 'Mohan', 'One ', 'A', '2018-12-15', '0', 'A'),
(1, 'Megha', 'Mohan', 'One ', 'A', '2018-12-28', 'P', '0'),
(2, 'Madhu', 'mahadev', 'One ', 'A', '2018-12-05', 'P', '0');

-- --------------------------------------------------------

--
-- Table structure for table `subjects1`
--

CREATE TABLE `subjects1` (
  `subjectname` varchar(20) NOT NULL,
  `subjectcode` varchar(20) NOT NULL,
  `subjecttype` varchar(20) NOT NULL,
  `classname` varchar(20) NOT NULL,
  `teachername` varchar(100) NOT NULL,
  `passmarks` varchar(20) NOT NULL,
  `fullmarks` varchar(20) NOT NULL,
  `description` varchar(20) NOT NULL,
  `created_at` varchar(100) NOT NULL,
  `modified_at` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects1`
--

INSERT INTO `subjects1` (`subjectname`, `subjectcode`, `subjecttype`, `classname`, `teachername`, `passmarks`, `fullmarks`, `description`, `created_at`, `modified_at`) VALUES
('Maths', 'Mat1', 'Mandatory', 'One', 'Nisha', '25', '100', 'dfghj', '2018-12-31 06:18:41', ''),
('Science', '12', 'Optional', 'One', 'Nisha', '12', '40', 'GFHJK', '2018-12-31 06:19:11', '');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teachername` varchar(15) NOT NULL,
  `subject` varchar(1000) NOT NULL,
  `phonenumber` varchar(1000) NOT NULL,
  `presentadd` varchar(1000) NOT NULL,
  `permanentadd` varchar(1000) NOT NULL,
  `gender` varchar(1000) NOT NULL,
  `bloodgroup` varchar(1000) NOT NULL,
  `religion` varchar(1000) NOT NULL,
  `dob` varchar(1000) NOT NULL,
  `joiningdate` varchar(1000) NOT NULL,
  `role` varchar(1000) NOT NULL,
  `salary` varchar(1000) NOT NULL,
  `salarytype` varchar(1000) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `file` varchar(1000) NOT NULL,
  `teacherpassword` varchar(1000) NOT NULL,
  `description` mediumtext NOT NULL,
  `fb` varchar(1000) NOT NULL,
  `linkedin` varchar(1000) NOT NULL,
  `insta` varchar(1000) NOT NULL,
  `twt` varchar(1000) NOT NULL,
  `created_at` varchar(1000) NOT NULL,
  `modified_at` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teachername`, `subject`, `phonenumber`, `presentadd`, `permanentadd`, `gender`, `bloodgroup`, `religion`, `dob`, `joiningdate`, `role`, `salary`, `salarytype`, `email`, `file`, `teacherpassword`, `description`, `fb`, `linkedin`, `insta`, `twt`, `created_at`, `modified_at`) VALUES
('Nisha', 'Maths1', '9343759642', '#64 Main road cubbenpet bangalore', '#64 Main road cubbenpet bangalore', 'Female', 'O+', 'Hindhu', '2018-12-14', '2018-12-22', 'Teacher', '15000', 'Monthly', 'meghabm07@gmail.com', '21.jpg', '123', 'sdfgh', 'sdfgh', 'fgh', 'fgh', 'fgh', '2018-12-31 08:24:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `teachers_attendence`
--

CREATE TABLE `teachers_attendence` (
  `teachername` varchar(255) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `attendencedate` varchar(1000) NOT NULL,
  `present` varchar(100) NOT NULL,
  `absent` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `classname` varchar(20) NOT NULL,
  `sectionname` varchar(100) NOT NULL,
  `subjectname` varchar(20) NOT NULL,
  `teachername` varchar(100) NOT NULL,
  `day` varchar(20) NOT NULL,
  `roomno` varchar(20) NOT NULL,
  `period` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`classname`, `sectionname`, `subjectname`, `teachername`, `day`, `roomno`, `period`) VALUES
('One ', 'A', 'Maths', 'Nisha', 'Monday', '12', '6'),
('One ', 'A', 'Maths', 'Nisha', 'Monday', '23', '5'),
('One ', 'A', 'Science', 'Nisha', 'Monday', '111111', '4'),
('One ', 'A', 'Maths', 'Nisha', 'Monday', '43', '3'),
('One ', 'A', 'Maths', 'Nisha', 'Monday', '23', '2'),
('One ', 'A', 'Maths', 'Nisha', 'Monday', '12', '1'),
('One ', 'A', 'Maths', 'Nisha', 'Tuesday', '12', '6'),
('One ', 'A', 'Maths', 'Nisha', 'Tuesday', '23', '5'),
('One ', 'A', 'Maths', 'Nisha', 'Tuesday', '34', '4'),
('One ', 'A', 'Maths', 'Nisha', 'Tuesday', '43', '3'),
('One ', 'A', 'Maths', 'Nisha', 'Tuesday', '23', '2'),
('One ', 'A', 'Maths', 'Nisha', 'Tuesday', '12', '1'),
('One ', 'A', 'Maths', 'Nisha', 'Wednesday', '12', '6'),
('One ', 'A', 'Maths', 'Nisha', 'Wednesday', '23', '5'),
('One ', 'A', 'Maths', 'Nisha', 'Wednesday', '34', '4'),
('One ', 'A', 'Maths', 'Nisha', 'Wednesday', '43', '3'),
('One ', 'A', 'Maths', 'Nisha', 'Wednesday', '23', '2'),
('One ', 'A', 'Maths', 'Nisha', 'Wednesday', '12', '1'),
('One ', 'A', 'Maths', 'Nisha', 'Thursday', '12', '6'),
('One ', 'A', 'Maths', 'Nisha', 'Thursday', '23', '5'),
('One ', 'A', 'Maths', 'Nisha', 'Thursday', '34', '4'),
('One ', 'A', 'Maths', 'Nisha', 'Thursday', '43', '3'),
('One ', 'A', 'Maths', 'Nisha', 'Thursday', '23', '2'),
('One ', 'A', 'Maths', 'Nisha', 'Thursday', '12', '1'),
('One ', 'A', 'Maths', 'Nisha', 'Friday', '12', '6'),
('One ', 'A', 'Maths', 'Nisha', 'Friday', '23', '5'),
('One ', 'A', 'Maths', 'Nisha', 'Friday', '34', '4'),
('One ', 'A', 'Maths', 'Nisha', 'Friday', '43', '3'),
('One ', 'A', 'Maths', 'Nisha', 'Friday', '23', '2'),
('One ', 'A', 'Maths', 'Nisha', 'Friday', '12', '1'),
('One ', 'A', 'Maths', 'Nisha', 'Saturday', '12', '1'),
('One ', 'A', 'Science', 'Nisha', 'Saturday', '', '2'),
('One ', 'A', 'Maths', 'Nisha', 'Saturday', '43', '3'),
('One ', 'A', 'Maths', 'Nisha', '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `todolist`
--

CREATE TABLE `todolist` (
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `start` varchar(100) NOT NULL,
  `end` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `todolist`
--

INSERT INTO `todolist` (`title`, `description`, `start`, `end`) VALUES
('fd', 'awes', '2018-12-11', ''),
('asds', 'sds', '2018-12-25', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`classname`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD KEY `classname` (`classname`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`rollno`),
  ADD KEY `classname` (`classname`);

--
-- Indexes for table `subjects1`
--
ALTER TABLE `subjects1`
  ADD PRIMARY KEY (`subjectname`),
  ADD KEY `subjects1_ibfk_1` (`classname`),
  ADD KEY `subjects1_ibfk_2` (`teachername`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teachername`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD KEY `classname` (`classname`),
  ADD KEY `timetable_ibfk_3` (`subjectname`),
  ADD KEY `teachername` (`teachername`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `rollno` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sections`
--
ALTER TABLE `sections`
  ADD CONSTRAINT `sections_ibfk_1` FOREIGN KEY (`classname`) REFERENCES `classes` (`classname`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`classname`) REFERENCES `classes` (`classname`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subjects1`
--
ALTER TABLE `subjects1`
  ADD CONSTRAINT `subjects1_ibfk_1` FOREIGN KEY (`classname`) REFERENCES `classes` (`classname`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subjects1_ibfk_2` FOREIGN KEY (`teachername`) REFERENCES `teachers` (`teachername`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timetable`
--
ALTER TABLE `timetable`
  ADD CONSTRAINT `timetable_ibfk_1` FOREIGN KEY (`classname`) REFERENCES `classes` (`classname`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `timetable_ibfk_3` FOREIGN KEY (`subjectname`) REFERENCES `subjects1` (`subjectname`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `timetable_ibfk_4` FOREIGN KEY (`teachername`) REFERENCES `teachers` (`teachername`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
