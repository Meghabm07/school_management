        var todolist = new Array();
               <?php
                   foreach($blogs as $welcome)
                   { 
               ?>
                   todolist.push(
                                  {
                                     title: <?php echo $welcome->title; ?> , 
                                     start: <?php echo $welcome->start; ?>,
                                     end: <?php echo $welcome->end; ?>
                                  }
                    );    
                <?php 
                   } 
                ?>
       $(document).ready(function() {
        $('#calendar').fullCalendar({
            eventSources: todolist
        });
     });

        
      $(document).ready(function(){
         $('#add').click(function(){
            var start_date   = $('#start_date').val();
            console.log(start_date);

           var end_date = $('#end_date').val();
           console.log(end_date);
            
           var title   = $('#title').val();
           console.log(title);

           var description   = $('#description').val();
           console.log(description);     
        
           $.ajax({       
             type   : "POST",
             url    : "<?php echo site_url('Admin_Controller/add_events'); ?>",
             data   : { title : title , description: description, start_date: start_date, end_date:end_date},               
             async  : false,
             success: function(data){ 
                  alert('success');
             },
             error: function (error) {
                 
             }
          }); 
        
         }); 

        });