<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>KDS SCHOOL MANAGEMENT SYSTEM</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>/assets/img/favicon.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/animate.css">
    <!-- jvectormap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jvectormap/jquery-jvectormap-2.0.3.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-editable.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/normalize.css">
    <!-- charts CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/c3.min.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/responsive.css">
    <!-- modernizr JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/modernizr-2.8.3.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
    <style type="text/css">
        #search
        {
            width: 50%; height: 30px;
            border-radius: 20px;
            float: right;
        }
        #icon
        {
            font-size:26px; float: right;
        }
        .nav-tabs.custom-menu-wrap li a, .nav-tabs.custom-menu-wrap li.open a 
        {
             border: 1px solid transparent;
             padding: 15px 19px;
             font-size: 15px;
        }
        @media (max-width: 767px)
        {
           #search{
            display: none;
           }
        }
        td
        {
            text-align: left;
        }
    </style>
</head>

<body>
    <div class="header-top-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="admin-logo">
                        <a href="<?php echo base_url(); ?>Admin_Controller/index"><img src="<?php echo base_url(); ?>/assets/img/logo/final_logo.png" alt="" />
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-sm-0 col-xs-12">
                </div>
                <div class="col-lg-4 col-md-9 col-sm-6 col-xs-12">
                    <div class="header-right-info">
                        <ul class="nav navbar-nav mai-top-nav header-right-menu">
                            <li class="nav-item dropdown">
                                <a href="<?php echo base_url(); ?>Admin_Controller/Calender"><span class="glyphicon glyphicon-calendar" title="Calendar"></span></a>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><span class="adminpro-icon adminpro-chat-pro" title="Messages"></span><span class="indicator-ms"></span></a>
                                <div role="menu" class="author-message-top dropdown-menu animated flipInX">
                                    <div class="message-single-top">
                                        <h1>No Messages Yet</h1>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                    <span class="adminpro-icon adminpro-user-rounded header-riht-inf" title="Profile"></span>
                                    <span class="admin-name" title="Profile">
                                     <?php 
                                        if($data=$this->session->userdata('user'))
                                        echo $data['uname'];
                                     ?>
                                     </span>
                                    <span class="author-project-icon adminpro-icon adminpro-down-arrow"></span>
                                </a>
                                <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated flipInX">
                                    <li><a href="<?php echo base_url(); ?>Admin_Controller/viewprofile""><span class="adminpro-icon adminpro-user-rounded author-log-ic"></span>My Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Admin_Controller/editprofile"><span class="adminpro-icon adminpro-checked-pro author-log-ic"></span>Edit Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Authentication_Controller/logout"><span class="adminpro-icon adminpro-locked author-log-ic"></span>Log Out</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header top area end-->
    <!-- Main Menu area start-->
    <div class="main-menu-area mg-t-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs custom-menu-wrap">
                        <li><a href="<?php echo base_url(); ?>Admin_Controller/index"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a>
                        </li>
                        <li><a data-toggle="tab" href="#Attendence"><span class="glyphicon glyphicon-calendar"></span> Attendence</a>
                        </li>
                        <li ><a data-toggle="tab" href="#Class"><span class="glyphicon glyphicon-th-list"></span>  Class</a>
                        </li>
                        <li><a  href="<?php echo base_url(); ?>Student_Controller/parents_page"><i class='fas fa-users' style='font-size:20px'></i> Parents</a>
                        </li>
                        <li><a data-toggle="tab" href="#Section"><span class="glyphicon glyphicon-th-large"></span> Section</a>
                        </li>
                        <li><a data-toggle="tab" href="#Students"><span class="glyphicon glyphicon-user"></span> Students</a>
                        </li>
                        <li ><a data-toggle="tab" href="#Subjects"><span class="glyphicon glyphicon-book"></span>  Subjects</a>
                        </li>                        
                        <li  class="active"><a data-toggle="tab" href="#Teachers"><i class='fas fa-user-friends' style='font-size:20px'></i> Teachers</a>
                        </li>
                        <li><a data-toggle="tab" href="#Timetable"><span class="glyphicon glyphicon-calendar"></span> Time Table</a>
                        </li>
                    </ul>
                    <div class="tab-content custom-menu-content">
                        <div id="Attendence" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Student_Controller/student_attendence">Student Attendence</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/teacher_attendence">Teacher Attendece</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Class" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Class_Controller/class_page">View Class</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Class_Controller/Add_class">Add Class</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Section" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Section_Controller/Section_page">View Section</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Section_Controller/Add_section">Add Section</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Students" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>student_Controller/view_students">View Students</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Student_Controller/student_admission">Student Admission</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Subjects" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/View_Subjects">View Subjects</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/Add_Subjects">Add Subjects</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Teachers" class="tab-pane in active  tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teachers_page">View Teachers</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/Add_Teacher">Add Teachers</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Timetable" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/View_timetable">View Time-Table</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/Add_timetable">Add Time-Table</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Menu area End-->
    <!-- Mobile Menu start -->
    <div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul class="mobile-menu-nav">
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Admin_Controller/index">Dashboard <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#demo" href="">Attendence <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="demo" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Student_Controller/student_attendence">Student Attendence</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teacher_attendence">Teacher Attendece</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#class1" href="">Class <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="class1" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Class_Controller/class_page">View Class</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Class_Controller/Add_class">Add Class</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Student_Controller/parents_page">Parents <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Tablesmob" href="">Sections <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Tablesmob" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Section_Controller/Section_page">View Section</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Section_Controller/Add_section">Add Section</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Tablesmob" href="">Students <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Tablesmob" class="collapse dropdown-header-top">
                                       <li><a href="<?php echo base_url(); ?>Student_Controller/student_admission">Student Admission</a>
                                       </li>
                                       <li><a href="<?php echo base_url(); ?>Student_Controller/view_students">View Students</a>
                                       </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Appviewsmob" href="">Subjects <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Appviewsmob" class="collapse dropdown-header-top">
                                         <li><a href="<?php echo base_url(); ?>Subject_Controller/View_Subjects">View Subjects</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/Add_Subjects">Add Subjects</a>
                                </li>
                                    </ul>
                                </li>
                                 <li><a data-toggle="collapse" data-target="#teacher1" href="">Teachers <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="teacher1" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teachers_page">View Teachers</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Add_Teacher">Add Teacher</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Pagemob" href="">Time Table <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Pagemob" class="collapse dropdown-header-top">
                                      <li><a href="<?php echo base_url(); ?>Timetable_Controller/View_timetable">View Time-Table</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/Add_timetable">Add Time-Table</a>
                                </li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu end -->
    <br>
    <br>
    <!-- Data table area Start-->
    <div class="admin-dashone-data-table-area mg-b-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sparkline8-list shadow-reset">
                        <div class="sparkline8-hd">
                            <div class="main-sparkline8-hd">
                                <div class="confirm-div">
                                 </div>
                                  <div class="confirm-div1">
                                 </div>
                                  <div class="confirm-div2">
                                 </div>
                                <a href="<?php echo base_url(); ?>Teacher_Controller/Add_Teacher"><button type="button" class="btn btn-custon-rounded-four btn-primary" style="float: right;">Add Teacher</button></a>
                                <h1><i class='fas fa-user-friends' style='font-size:20px'></i>  Manage Teachers</h1>
                            </div>
                        </div>
                        <div class="sparkline8-graph">
                            <div class="datatable-dashv1-list custom-datatable-overright">
                                <div id="toolbar">
                                    <select class="form-control">
                                        <option value="">Export Basic</option>
                                        <option value="all">Export All</option>
                                        <option value="selected">Export Selected</option>
                                    </select>
                                </div>
                                <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                    <thead>
                                        <tr>
                                            <th data-field="id">ID</th>
                                            <th data-field="Photo" >Photo</th>
                                            <th data-field="Teacher Name" >Teacher Name</th>
                                            <th data-field="Subject " >Subject</th>
                                            <th data-field="Phone Number" >Phone Number</th>
                                            <th data-field="Email">Email </th>
                                            <th data-field="Joining Date" >Joining Date</th>
                                            <th data-field="Salary">Salary</th>
                                            <th data-field="Action">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php 
                                         $i=0;
                                         if($blogs)
                                         { 
                                           foreach($blogs as $welcome)
                                           { 
                                             $i++;
                                       ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td>
                                                <div class="author-per-img">
                                                    <img src="<?php echo base_url('teachersphoto/'.$welcome->file); ?>" alt="" />
                                                </div>
                                            </td>
                                            <td><?php echo $welcome->teachername; ?></td>
                                            <td><?php echo $welcome->subject; ?></td>
                                            <td><?php echo $welcome->phonenumber; ?></td>
                                            <td><?php echo $welcome->email; ?></td>
                                            <td><?php echo $welcome->joiningdate; ?></td>
                                            <td><?php echo $welcome->salary; ?></td>
                                            <td>
                                                <a href="<?php echo base_url('Teacher_Controller/View_Teacher/'.$welcome->teachername); ?>">
                                                    <button type="button" class="btn btn-xs btn-custon-rounded-four btn-primary ">
                                                      View 
                                                    </button>
                                                </a>
                                                 <a href="<?php echo base_url('Teacher_Controller/Edit_Teacher/'.$welcome->teachername); ?>">
                                                    <button type="button" class="btn btn-xs btn-custon-rounded-four btn-warning ">
                                                      Edit 
                                                    </button>
                                                </a>
                                                <a href="<?php echo base_url('Teacher_Controller/Delete_Teacher/'.$welcome->teachername); ?>">
                                                    <button type="button" class="btn btn-xs btn-custon-rounded-four btn-danger">
                                                     Delete 
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                            }
                                        }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Data table area End-->
        <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <!-- Footer Start-->
    <div class="footer-copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-copy-right">
                        <p>Copyright &#169; 2018 Colorlib All rights reserved. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
    <!-- Chat Box Start-->
    <div class="chat-list-wrap">
        <div class="chat-list-adminpro">
            <div class="chat-button">
                <span data-toggle="collapse" data-target="#chat" class="chat-icon-link"><i class="fa fa-comments"></i></span>
            </div>
            <div id="chat" class="collapse chat-box-wrap shadow-reset animated zoomInLeft">
                <div class="chat-main-list">
                    <div class="chat-heading">
                        <h2>Messanger</h2>
                    </div>
                    <div class="chat-content chat-scrollbar">
                        <div class="author-chat">
                            <h3>Monica <span class="chat-date">10:15 am</span></h3>
                            <p>Hi, what you are doing and where are you gay?</p>
                        </div>
                        <div class="client-chat">
                            <h3>Mamun <span class="chat-date">10:10 am</span></h3>
                            <p>Now working in graphic design with coding and you?</p>
                        </div>
                        <div class="author-chat">
                            <h3>Monica <span class="chat-date">10:05 am</span></h3>
                            <p>Practice in programming</p>
                        </div>
                        <div class="client-chat">
                            <h3>Mamun <span class="chat-date">10:02 am</span></h3>
                            <p>That's good man! carry on...</p>
                        </div>
                    </div>
                    <div class="chat-send">
                        <input type="text" placeholder="Type..." />
                        <span><button type="submit">Send</button></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Chat Box End-->
    <!-- jquery
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/counterup/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/waypoints.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/counterup-active.js"></script>
    <!-- peity JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/peity/jquery.peity.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/peity/peity-active.js"></script>
    <!-- sparkline JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.tooltip.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.spline.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.resize.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/flot-active.js"></script>
    <!-- map JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/map/raphael.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/jquery.mapael.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/france_departments.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/world_countries.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/usa_states.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/map-active.js"></script>
    <!-- data table JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/tableExport.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/data-table-active.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-editable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-editable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/colResizable-1.5.source.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-export.js"></script>
    <!-- switcher JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/switcher/styleswitch.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/switcher/switch-active.js"></script>
    <!-- main JS
		============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>

<script type="text/javascript">
          $(document).ready(function() {
   $('.confirm-div').hide();
    <?php if($this->session->flashdata('msg')){ ?>
    $('.confirm-div').html(' <div class="alert alert-success alert-mg-b" role="alert"><strong>Success!</strong> Teacher Added </div>').show();
    <?php } ?>
    });
    </script>
    <script type="text/javascript">
          $(document).ready(function() {
   $('.confirm-div1').hide();
    <?php if($this->session->flashdata('msg1')){ ?>
    $('.confirm-div1').html(' <div class="alert alert-success alert-mg-b" role="alert"><strong>Success!</strong> Teacher Updated </div>').show();
    <?php } ?>
    });
    </script>
    <script type="text/javascript">
          $(document).ready(function() {
   $('.confirm-div2').hide();
    <?php if($this->session->flashdata('msg2')){ ?>
    $('.confirm-div2').html(' <div class="alert alert-success alert-mg-b" role="alert"><strong>Success!</strong> Teacher Deleted </div>').show();
    <?php } ?>
});
</script>
</body>

</html>