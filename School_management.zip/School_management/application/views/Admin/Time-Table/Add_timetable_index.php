<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>KDS SCHOOL MANAGEMENT SYSTEM</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>/assets/img/favicon.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/animate.css">
    <!-- jvectormap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jvectormap/jquery-jvectormap-2.0.3.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-editable.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/normalize.css">
    <!-- charts CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/c3.min.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/responsive.css">
     <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/animate.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/normalize.css">
    <!-- notifications CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Lobibox.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/notifications.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/responsive.css">
    <!-- modernizr JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- modernizr JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/modernizr-2.8.3.min.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
    <style type="text/css">
       #mon,#tue,#wed,#thu,#fri,#sat{
        background-color: white;
       }
        #search
        {
            width: 50%; height: 30px;
            border-radius: 20px;
            float: right;
        }
        #icon
        {
            font-size:26px; float: right;
        }
        .nav-tabs.custom-menu-wrap li a, .nav-tabs.custom-menu-wrap li.open a 
        {
             border: 1px solid transparent;
             padding: 15px 19px;
             font-size: 15px;
        }
        #View {
            background-color: #E6F4F9;
        }
        @media (max-width: 767px)
        {
           #search{
            display: none;
           }
        }
    </style>
</head>

<body>
    <div class="header-top-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="admin-logo">
                        <a href="<?php echo base_url(); ?>Admin_Controller/index"><img src="<?php echo base_url(); ?>/assets/img/logo/final_logo.png" alt="" />
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-sm-0 col-xs-12">
                </div>
                <div class="col-lg-4 col-md-9 col-sm-6 col-xs-12">
                    <div class="header-right-info">
                        <ul class="nav navbar-nav mai-top-nav header-right-menu">
                            <li class="nav-item dropdown">
                                <a href="<?php echo base_url(); ?>Admin_Controller/Calender"><span class="glyphicon glyphicon-calendar" title="Calendar"></span></a>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><span class="adminpro-icon adminpro-chat-pro" title="Messages"></span><span class="indicator-ms"></span></a>
                                <div role="menu" class="author-message-top dropdown-menu animated flipInX">
                                    <div class="message-single-top">
                                        <h1>No Messages Yet</h1>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                    <span class="adminpro-icon adminpro-user-rounded header-riht-inf" title="Profile"></span>
                                    <span class="admin-name" title="Profile">
                                     <?php 
                                        if($data=$this->session->userdata('user'))
                                        echo $data['uname'];
                                     ?>
                                     </span>
                                    <span class="author-project-icon adminpro-icon adminpro-down-arrow"></span>
                                </a>
                                <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated flipInX">
                                    <li><a href="<?php echo base_url(); ?>Admin_Controller/viewprofile""><span class="adminpro-icon adminpro-user-rounded author-log-ic"></span>My Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Admin_Controller/editprofile"><span class="adminpro-icon adminpro-checked-pro author-log-ic"></span>Edit Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Authentication_Controller/logout"><span class="adminpro-icon adminpro-locked author-log-ic"></span>Log Out</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header top area end-->
    <!-- Main Menu area start-->
    <div class="main-menu-area mg-t-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs custom-menu-wrap">
                        <li ><a href="<?php echo base_url(); ?>Admin_Controller/index"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a>
                        </li>
                        <li><a data-toggle="tab" href="#Attendence"><span class="glyphicon glyphicon-calendar"></span> Attendence</a>
                        </li>
                        <li ><a data-toggle="tab" href="#Class"><span class="glyphicon glyphicon-th-list"></span>  Class</a>
                        </li>
                        <li><a  href="<?php echo base_url(); ?>Student_Controller/parents_page"><i class='fas fa-users' style='font-size:20px'></i> Parents</a>
                        </li>
                        <li><a data-toggle="tab" href="#Section"><span class="glyphicon glyphicon-th-large"></span> Section</a>
                        </li>
                        <li><a data-toggle="tab" href="#Students"><span class="glyphicon glyphicon-user"></span> Students</a>
                        </li>
                        <li><a data-toggle="tab" href="#Subjects"><span class="glyphicon glyphicon-book"></span>  Subjects</a>
                        </li>                        
                        <li><a data-toggle="tab" href="#Teachers"><i class='fas fa-user-friends' style='font-size:20px'></i> Teachers</a>
                        </li>
                        <li class="active"><a data-toggle="tab" href="#Timetable"><span class="glyphicon glyphicon-calendar"></span> Time Table</a>
                        </li>
                    </ul>
                    <div class="tab-content custom-menu-content">
                        <div id="Attendence" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Student_Controller/student_attendence">Student Attendence</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/teacher_attendence">Teacher Attendece</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Class" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Class_Controller/class_page">View Class</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Class_Controller/Add_class">Add Class</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Section" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Section_Controller/Section_page">View Section</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Section_Controller/Add_section">Add Section</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Students" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>student_Controller/view_students">View Students</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Student_Controller/student_admission">Student Admission</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Subjects" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/View_Subjects">View Subjects</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/Add_Subjects">Add Subjects</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Teachers" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teachers_page">View Teachers</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/Add_Teacher">Add Teachers</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Timetable" class="tab-pane in active tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/View_timetable">View Time-Table</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/Add_timetable">Add Time-Table</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Menu area End-->
    <!-- Mobile Menu start -->
    <div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul class="mobile-menu-nav">
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Admin_Controller/index">Dashboard <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#demo" href="">Attendence <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="demo" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Student_Controller/student_attendence">Student Attendence</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teacher_attendence">Teacher Attendece</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#class1" href="">Class <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="class1" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Class_Controller/class_page">View Class</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Class_Controller/Add_class">Add Class</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Student_Controller/parents_page">Parents <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Tablesmob" href="">Sections <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Tablesmob" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Section_Controller/Section_page">View Section</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Section_Controller/Add_section">Add Section</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Tablesmob" href="">Students <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Tablesmob" class="collapse dropdown-header-top">
                                       <li><a href="<?php echo base_url(); ?>Student_Controller/student_admission">Student Admission</a>
                                       </li>
                                       <li><a href="<?php echo base_url(); ?>Student_Controller/view_students">View Students</a>
                                       </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Appviewsmob" href="">Subjects <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Appviewsmob" class="collapse dropdown-header-top">
                                         <li><a href="<?php echo base_url(); ?>Subject_Controller/View_Subjects">View Subjects</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/Add_Subjects">Add Subjects</a>
                                </li>
                                    </ul>
                                </li>
                                 <li><a data-toggle="collapse" data-target="#teacher1" href="">Teachers <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="teacher1" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teachers_page">View Teachers</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Add_Teacher">Add Teacher</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Pagemob" href="">Time Table <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Pagemob" class="collapse dropdown-header-top">
                                      <li><a href="<?php echo base_url(); ?>Timetable_Controller/View_timetable">View Time-Table</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/Add_timetable">Add Time-Table</a>
                                </li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu end -->
    <br>
    <br>
         <!-- Basic Form Start -->
     <div class="basic-form-area mg-b-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sparkline12-list shadow-reset mg-t-30">
                        <div class="sparkline12-hd">
                            <div class="main-sparkline12-hd">
                                <div class="alert alert-danger" id="danger1" style="display: none;">
                                    <strong>Error!</strong> Please select day
                                </div>
                               <a href="<?php echo base_url(); ?>Timetable_Controller/View_timetable"><button type="button" class="btn btn-custon-rounded-four btn-primary" style="float: right;">View Time-Table</button></a>
                                <h1><span class="glyphicon glyphicon-calendar"></span> Add Time-Table for Class <span id="classnames"><?php echo $classname; ?></span> "<span id="sections"><?php echo  $section; ?></span>" Section</h1>
                            </div>
                        </div>
                        <div class="sparkline12-graph">
                            <div class="basic-login-form-ad">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="all-form-element-inner">
                                                 <div class="confirm-div">
                                                    <div class="form-select-list">
                                                                <select class="form-control custom-select-value"  name="day4" id="d" required="" style="width: 200px;">
                                                                    <option value="" disabled selected>Select Day</option>
                                                                    <option value="Monday">Monday</option>
                                                                    <option value="Tuesday">Tuesday</option>
                                                                    <option value="Wednesday">Wednesday</option>
                                                                    <option value="Thursday">Thursday</option>
                                                                    <option value="Friday">Friday</option>
                                                                    <option value="Saturday">Saturday</option>
                                                                </select>
                                                    </div>
                                                 </div>
                                                 <br>
                                                 <table data-toggle="table" border="0"  >
                                                    <thead>
                                                      <tr>
                                                        <th>Period</th>
                                                        <th>Day</th>
                                                        <th>Subject Name</th>
                                                        <th>Teacher Name</th>
                                                        <th>Room No</th>
                                                        <th>Action</th>
                                                      </tr>
                                                    </thead>
                                                     <tbody>
                                                        <!-- Period 1 -->
                                                       <tr>
                                                         <form method="POST" >
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" value="1" id="period" name="period" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                           <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" value="" id="day1" name="day1" required="" >
                                                            </div>
                                                         </td> 
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="subjectname" name="subjectname" style="width: 150px;" required="">
                                                                    <?php if($blogs1)
                                                                    {
                                                                        foreach ($blogs1 as $welcome1) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome1->subjectname; ?>"><?php echo $welcome1->subjectname; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="teachername" name="teachername" style="width: 150px;" required="">
                                                                    <?php if($blogs2)
                                                                    {
                                                                        foreach ($blogs2 as $welcome2) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome2->teachername; ?>"><?php echo $welcome2->teachername; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" id="roomno" name="roomno" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <button id="add1" class="btn btn-sm btn-primary login-submit-cs" type="submit">Add Time-Table</button>
                                                         </td>
                                                         </form>
                                                       </tr>
                                                       <!-- Period 2 -->
                                                       <tr>
                                                         <form method="POST" >
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" value="2" id="period2" name="period" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                           <div class="form-select-list">
                                                                 <input type="text"  class="form-control basic-ele-mg-b-10" value="" id="day2" name="day1" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="subjectname2" name="subjectname" style="width: 150px;" required="">
                                                                    <?php if($blogs1)
                                                                    {
                                                                        foreach ($blogs1 as $welcome1) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome1->subjectname; ?>"><?php echo $welcome1->subjectname; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="teachername2" name="teachername" style="width: 150px;" required="">
                                                                    <?php if($blogs2)
                                                                    {
                                                                        foreach ($blogs2 as $welcome2) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome2->teachername; ?>"><?php echo $welcome2->teachername; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" id="roomno2" name="roomno" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <button id="add2" class="btn btn-sm btn-primary login-submit-cs" type="submit">Add Time-Table</button>
                                                         </td>
                                                         </form>
                                                       </tr>
                                                       <!-- Period 3 -->
                                                       <tr>
                                                         <form method="POST" >
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" value="3" id="period3" name="period" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                           <div class="form-select-list">
                                                                 <input type="text"  class="form-control basic-ele-mg-b-10" value="" id="day3" name="day1" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="subjectname3" name="subjectname" style="width: 150px;" required="">
                                                                    <?php if($blogs1)
                                                                    {
                                                                        foreach ($blogs1 as $welcome1) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome1->subjectname; ?>"><?php echo $welcome1->subjectname; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="teachername3" name="teachername" style="width: 150px;" required="">
                                                                    <?php if($blogs2)
                                                                    {
                                                                        foreach ($blogs2 as $welcome2) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome2->teachername; ?>"><?php echo $welcome2->teachername; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" id="roomno3" name="roomno" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <button id="add3" class="btn btn-sm btn-primary login-submit-cs" type="submit">Add Time-Table</button>
                                                         </td>
                                                         </form>
                                                       </tr>
                                                       <!-- Period 4 -->
                                                       <tr>
                                                         <form method="POST" >
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" value="4" id="period4" name="period4" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                           <div class="form-select-list">
                                                                 <input type="text"  class="form-control basic-ele-mg-b-10" value="" id="day4" name="day1" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="subjectname4" name="subjectname" style="width: 150px;" required="">
                                                                    <?php if($blogs1)
                                                                    {
                                                                        foreach ($blogs1 as $welcome1) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome1->subjectname; ?>"><?php echo $welcome1->subjectname; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="teachername4" name="teachername" style="width: 150px;" required="">
                                                                    <?php if($blogs2)
                                                                    {
                                                                        foreach ($blogs2 as $welcome2) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome2->teachername; ?>"><?php echo $welcome2->teachername; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" id="roomno4" name="roomno" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <button id="add4" class="btn btn-sm btn-primary login-submit-cs" type="submit">Add Time-Table</button>
                                                         </td>
                                                         </form>
                                                       </tr>
                                                       <!-- Period 5 -->
                                                       <tr>
                                                         <form method="POST" >
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" value="5" id="period5" name="period5" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                           <div class="form-select-list">
                                                                 <input type="text"  class="form-control basic-ele-mg-b-10" value="" id="day5" name="day1" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="subjectname5" name="subjectname" style="width: 150px;" required="">
                                                                    <?php if($blogs1)
                                                                    {
                                                                        foreach ($blogs1 as $welcome1) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome1->subjectname; ?>"><?php echo $welcome1->subjectname; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="teachername5" name="teachername" style="width: 150px;" required="">
                                                                    <?php if($blogs2)
                                                                    {
                                                                        foreach ($blogs2 as $welcome2) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome2->teachername; ?>"><?php echo $welcome2->teachername; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" id="roomno5" name="roomno" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <button id="add5" class="btn btn-sm btn-primary login-submit-cs" type="submit">Add Time-Table</button>
                                                         </td>
                                                         </form>
                                                       </tr>
                                                       <!-- Period 6 -->
                                                      <tr>
                                                         <form method="POST" >
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" value="6" id="period6" name="period6" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                           <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" value="" id="day6" name="day1" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="subjectname6" name="subjectname6" style="width: 150px;" required="">
                                                                    <?php if($blogs1)
                                                                    {
                                                                        foreach ($blogs1 as $welcome1) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome1->subjectname; ?>"><?php echo $welcome1->subjectname; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <select class="form-control custom-select-value" id="teachername6" name="teachername6" style="width: 150px;" required="">
                                                                    <?php if($blogs2)
                                                                    {
                                                                        foreach ($blogs2 as $welcome2) 
                                                                        {
                                                                     ?>
                                                                    <option value="<?php echo $welcome2->teachername; ?>"><?php echo $welcome2->teachername; ?></option>
                                                                    <?php
                                                                        }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <div class="form-select-list">
                                                                <input type="text"  class="form-control basic-ele-mg-b-10" id="roomno6" name="roomno6" required="" >
                                                            </div>
                                                         </td>
                                                         <td>
                                                             <button id="add6" class="btn btn-sm btn-primary login-submit-cs" type="submit">Add Time-Table</button>
                                                         </td>
                                                         </form>
                                                       </tr>
                                                      
                                                     </tbody>
                                                 </table>
                                            </form>
                                        </div>
                                        <br>
                                        <br>
                                        <br>
                                        <div class="alert alert-warning alert-mg-b" role="alert"><strong>Instruction!</strong> Please Add Teachers, Class, Sections Before Adding Time Table</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Basic Form End-->
        <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <!-- Footer Start-->
    <div class="footer-copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-copy-right">
                        <p>Copyright &#169; 2018 KDS All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
    <!-- jquery
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/counterup/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/waypoints.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/counterup-active.js"></script>
    <!-- peity JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/peity/jquery.peity.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/peity/peity-active.js"></script>
    <!-- sparkline JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.tooltip.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.spline.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.resize.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/flot-active.js"></script>
    <!-- map JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/map/raphael.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/jquery.mapael.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/france_departments.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/world_countries.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/usa_states.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/map-active.js"></script>
    <!-- data table JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/tableExport.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/data-table-active.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-editable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-editable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/colResizable-1.5.source.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-export.js"></script>
    <!-- switcher JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/switcher/styleswitch.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/switcher/switch-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>
       <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.scrollUp.min.js"></script>
    <!-- notification JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/Lobibox.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/notification-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="js/main.js"></script>
    <script type="text/javascript">
$(document).ready(function(){
  document.getElementById("period").disabled = true;
  document.getElementById("period2").disabled = true;
  document.getElementById("period3").disabled = true;
  document.getElementById("period4").disabled = true;
  document.getElementById("period5").disabled = true;
  document.getElementById("period6").disabled = true;
  document.getElementById("day1").disabled = true;
  document.getElementById("day2").disabled = true;
  document.getElementById("day3").disabled = true;
  document.getElementById("day4").disabled = true;
  document.getElementById("day5").disabled = true;
  document.getElementById("day6").disabled = true;
  $('#d').on('change', function(){
    
    var state = document.getElementById("d").value.length > 0;
    
    $('#day1').val($(this).val());
    
    $('#day2').val($(this).val());
    
    $('#day3').val($(this).val());
    
    $('#day4').val($(this).val());
    
    $('#day5').val($(this).val());
    
    $('#day6').val($(this).val());
  });
});
</script>
<script type="text/javascript">

  $(document).ready(function(){

       $('#add1').click(function(){
        var day = $('#day1').val();
        console.log(day);
        var len = day.length;
        console.log(len);
        if(len > 0 )
        {
         var period   = $('#period').val();
         var classname = document.getElementById("classnames").textContent;
         console.log(classname);

         var section = document.getElementById("sections").textContent;
         console.log(section);

         var day = $('#day1').val();
         console.log(day);

         var subjectname = $('#subjectname').val();
         console.log(subjectname);

         var teachername = $('#teachername').val();
         console.log(teachername);

           var roomno = $('#roomno').val();
           console.log(roomno);
         
          $.ajax({       
            type   : "POST",
            url    : "<?php echo site_url('Timetable_Controller/Add_timetable_to_database'); ?>",
            data   : { classname : classname , section: section, period: period, day:day, subjectname:subjectname, teachername:teachername, roomno:roomno},               
            async  : false,
            success: function(data){ 
                  if(data == 0)
                  {
                    Lobibox.notify('error', {
                    title: 'Error',
                    hideClass: 'zoomOutDown',
                    msg: 'Failed to Add Routine correctly!!!<br> Because Routine Already exits'
                    });
                 }
                 else 
                 {
                    Lobibox.notify('success', {
                    title: 'Success',
                    hideClass: 'zoomOutDown',
                    msg: 'Routine Added correctly!!!'
                    });
                }
            },
            error: function (error) {
                 
            }
        }); 
        }  
        else
        {
            $('#danger1').show(0).delay(3000).hide(0);
        }            
       });

      $('#add2').click(function(){

         var period   = $('#period2').val();
         var classname = document.getElementById("classnames").textContent;
         console.log(classname);

         var section = document.getElementById("sections").textContent;
         console.log(section);

         var day = $('#day2').val();
         console.log(day);

         var subjectname = $('#subjectname2').val();
         console.log(subjectname);

         var teachername = $('#teachername2').val();
         console.log(teachername);

         var roomno = $('#roomno2').val();
         console.log(roomno);

          $.ajax({       
            type   : "POST",
            url    : "<?php echo site_url('Timetable_Controller/Add_timetable_to_database'); ?>",
            data   : { classname : classname , section: section, period: period, day:day, subjectname:subjectname, teachername:teachername, roomno:roomno},               
            async  : false,
            success: function(data){ 
                  if(data == 0)
                  {
                    Lobibox.notify('error', {
                    title: 'Error',
                    hideClass: 'zoomOutDown',
                    msg: 'Failed to Add Routine correctly!!!<br> Because Routine Already exits'
                    });
                 }
                 else 
                 {
                    Lobibox.notify('success', {
                    title: 'Success',
                    hideClass: 'zoomOutDown',
                    msg: 'Routine Added correctly!!!'
                    });
                }
            },
            error: function (error) {
                 $("#failure").show(100);
                 $("#failure").delay(1000).slideUp(200).hide(200);
            }
        }); 
                      
       });

      $('#add3').click(function(){

          var period   = $('#period3').val();
          var classname = document.getElementById("classnames").textContent;
          console.log(classname);

          var section = document.getElementById("sections").textContent;
          console.log(section);

         var day = $('#day3').val();
         console.log(day);

         var subjectname = $('#subjectname3').val();
         console.log(subjectname);

         var teachername = $('#teachername3').val();
         console.log(teachername);

         var roomno = $('#roomno3').val();
         console.log(roomno);

          $.ajax({       
            type   : "POST",
            url    : "<?php echo site_url('Timetable_Controller/Add_timetable_to_database'); ?>",
            data   : { classname : classname , section: section, period: period, day:day, subjectname:subjectname, teachername:teachername, roomno:roomno},               
            async  : false,
            success: function(data){ 
                  if(data == 0)
                  {
                    Lobibox.notify('error', {
                    title: 'Error',
                    hideClass: 'zoomOutDown',
                    msg: 'Failed to Add Routine correctly!!!<br> Because Routine Already exits'
                    });
                 }
                 else 
                 {
                    Lobibox.notify('success', {
                    title: 'Success',
                    hideClass: 'zoomOutDown',
                    msg: 'Routine Added correctly!!!'
                    });
                }
            },
            error: function (error) {
                 $("#failure").show(100);
                 $("#failure").delay(1000).slideUp(200).hide(200);
            }
        }); 
                      
       });

      $('#add4').click(function(){

          var period   = $('#period4').val();
          var classname = document.getElementById("classnames").textContent;
          console.log(classname);

          var section = document.getElementById("sections").textContent;
          console.log(section);

         var day = $('#day4').val();
         console.log(day);

         var subjectname = $('#subjectname4').val();
         console.log(subjectname);

         var teachername = $('#teachername4').val();
         console.log(teachername);

         var roomno = $('#roomno4').val();
         console.log(roomno);

          $.ajax({       
            type   : "POST",
            url    : "<?php echo site_url('Timetable_Controller/Add_timetable_to_database'); ?>",
            data   : { classname : classname , section: section, period: period, day:day, subjectname:subjectname, teachername:teachername, roomno:roomno},               
            async  : false,
            success: function(data){ 
                  if(data == 0)
                  {
                    Lobibox.notify('error', {
                    title: 'Error',
                    hideClass: 'zoomOutDown',
                    msg: 'Failed to Add Routine correctly!!!<br> Because Routine Already exits'
                    });
                 }
                 else 
                 {
                    Lobibox.notify('success', {
                    title: 'Success',
                    hideClass: 'zoomOutDown',
                    msg: 'Routine Added correctly!!!'
                    });
                }
            },
            error: function (error) {
                 $("#failure").show(100);
                 $("#failure").delay(1000).slideUp(200).hide(200);
            }
        }); 
                      
       });

      $('#add5').click(function(){

          var period   = $('#period5').val();
          var classname = document.getElementById("classnames").textContent;
          console.log(classname);

          var section = document.getElementById("sections").textContent;
          console.log(section);

         var day = $('#day5').val();
         console.log(day);

         var subjectname = $('#subjectname5').val();
         console.log(subjectname);

         var teachername = $('#teachername5').val();
         console.log(teachername);

         var roomno = $('#roomno5').val();
         console.log(roomno);

          $.ajax({       
            type   : "POST",
            url    : "<?php echo site_url('Timetable_Controller/Add_timetable_to_database'); ?>",
            data   : { classname : classname , section: section, period: period, day:day, subjectname:subjectname, teachername:teachername, roomno:roomno},               
            async  : false,
            success: function(data){ 
                  if(data == 0)
                  {
                    Lobibox.notify('error', {
                    title: 'Error',
                    hideClass: 'zoomOutDown',
                    msg: 'Failed to Add Routine correctly!!!<br> Because Routine Already exits'
                    });
                 }
                 else 
                 {
                    Lobibox.notify('success', {
                    title: 'Success',
                    hideClass: 'zoomOutDown',
                    msg: 'Routine Added correctly!!!'
                    });
                }
            },
            error: function (error) {
                 $("#failure").show(100);
                 $("#failure").delay(1000).slideUp(200).hide(200);
            }
        }); 
                      
       });

      $('#add6').click(function(){

          var period   = $('#period6').val();
          var classname = document.getElementById("classnames").textContent;
          console.log(classname);

          var section = document.getElementById("sections").textContent;
          console.log(section);

         var day = $('#day6').val();
         console.log(day);

         var subjectname = $('#subjectname6').val();
         console.log(subjectname);

         var teachername = $('#teachername6').val();
         console.log(teachername);

         var roomno = $('#roomno6').val();
         console.log(roomno);

          $.ajax({       
            type   : "POST",
            url    : "<?php echo site_url('Timetable_Controller/Add_timetable_to_database'); ?>",
            data   : { classname : classname , section: section, period: period, day:day, subjectname:subjectname, teachername:teachername, roomno:roomno},               
            async  : false,
            success: function(data){ 
                  if(data == 0)
                  {
                    Lobibox.notify('error', {
                    title: 'Error',
                    hideClass: 'zoomOutDown',
                    msg: 'Failed to Add Routine correctly!!!<br> Because Routine Already exits'
                    });
                 }
                 else 
                 {
                    Lobibox.notify('success', {
                    title: 'Success',
                    hideClass: 'zoomOutDown',
                    msg: 'Routine Added correctly!!!'
                    });
                }
            },
            error: function (error) {
                 $("#failure").show(100);
                 $("#failure").delay(1000).slideUp(200).hide(200);
            }
        }); 
                      
       });   
  });
    </script>

</body>

</html>