<!doctype html>
<html class="no-js" lang="en">
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>KDS SCHOOL MANAGEMENT SYSTEM</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>/assets/img/favicon.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/animate.css">
    <!-- jvectormap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jvectormap/jquery-jvectormap-2.0.3.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-editable.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/normalize.css">
    <!-- charts CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/c3.min.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/responsive.css">
    <!-- modernizr JS
        ============================================ -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
    <style type="text/css">
        #search
        {
            width: 50%; height: 30px;
            border-radius: 20px;
            float: right;
        }
        #icon
        {
            font-size:26px; float: right;
        }
        .nav-tabs.custom-menu-wrap li a, .nav-tabs.custom-menu-wrap li.open a 
        {
             border: 1px solid transparent;
             padding: 15px 19px;
             font-size: 15px;
        }
        @media (max-width: 767px)
        {
           #search{
            display: none;
           }
        }
    </style>
</head>

<body>
    <div class="header-top-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="admin-logo">
                        <a href="<?php echo base_url(); ?>Admin_Controller/index"><img src="<?php echo base_url(); ?>/assets/img/logo/final_logo.png" alt="" />
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-sm-0 col-xs-12">
                </div>
                <div class="col-lg-4 col-md-9 col-sm-6 col-xs-12">
                    <div class="header-right-info">
                        <ul class="nav navbar-nav mai-top-nav header-right-menu">
                            <li class="nav-item dropdown">
                                <a href="<?php echo base_url(); ?>Admin_Controller/Calender"><span class="glyphicon glyphicon-calendar" title="Calendar"></span></a>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><span class="adminpro-icon adminpro-chat-pro" title="Messages"></span><span class="indicator-ms"></span></a>
                                <div role="menu" class="author-message-top dropdown-menu animated flipInX">
                                    <div class="message-single-top">
                                        <h1>No Messages Yet</h1>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                    <span class="adminpro-icon adminpro-user-rounded header-riht-inf" title="Profile"></span>
                                    <span class="admin-name" title="Profile">
                                     <?php 
                                        if($data=$this->session->userdata('user'))
                                        echo $data['uname'];
                                     ?>
                                     </span>
                                    <span class="author-project-icon adminpro-icon adminpro-down-arrow"></span>
                                </a>
                                <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated flipInX">
                                    <li><a href="<?php echo base_url(); ?>Admin_Controller/viewprofile""><span class="adminpro-icon adminpro-user-rounded author-log-ic"></span>My Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Admin_Controller/editprofile"><span class="adminpro-icon adminpro-checked-pro author-log-ic"></span>Edit Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Authentication_Controller/logout"><span class="adminpro-icon adminpro-locked author-log-ic"></span>Log Out</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header top area end-->
    <!-- Main Menu area start-->
    <div class="main-menu-area mg-t-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs custom-menu-wrap">
                        <li><a href="<?php echo base_url(); ?>Admin_Controller/index"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a>
                        </li>
                        <li><a data-toggle="tab" href="#Attendence"><span class="glyphicon glyphicon-calendar"></span> Attendence</a>
                        </li>
                        <li  class="active" ><a data-toggle="tab" href="#Class"><span class="glyphicon glyphicon-th-list"></span>  Class</a>
                        </li>
                        <li><a  href="<?php echo base_url(); ?>Student_Controller/parents_page"><i class='fas fa-users' style='font-size:20px'></i> Parents</a>
                        </li>
                        <li><a data-toggle="tab" href="#Section"><span class="glyphicon glyphicon-th-large"></span> Section</a>
                        </li>
                        <li><a data-toggle="tab" href="#Students"><span class="glyphicon glyphicon-user"></span> Students</a>
                        </li>
                        <li><a data-toggle="tab" href="#Subjects"><span class="glyphicon glyphicon-book"></span>  Subjects</a>
                        </li>                        
                        <li><a data-toggle="tab" href="#Teachers"><i class='fas fa-user-friends' style='font-size:20px'></i> Teachers</a>
                        </li>
                        <li><a data-toggle="tab" href="#Timetable"><span class="glyphicon glyphicon-calendar"></span> Time Table</a>
                        </li>
                    </ul>
                    <div class="tab-content custom-menu-content">
                        <div id="Attendence" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Student_Controller/student_attendence">Student Attendence</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/teacher_attendence">Teacher Attendece</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Class" class="tab-pane in active tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Class_Controller/class_page">View Class</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Class_Controller/Add_class">Add Class</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Section" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Section_Controller/Section_page">View Section</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Section_Controller/Add_section">Add Section</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Students" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>student_Controller/view_students">View Students</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Student_Controller/student_admission">Student Admission</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Subjects" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/View_Subjects">View Subjects</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/Add_Subjects">Add Subjects</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Teachers" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teachers_page">View Teachers</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Teacher_Controller/Add_Teacher">Add Teachers</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Timetable" class="tab-pane tab-custon-menu-bg animated flipInX">
                            <ul class="main-menu-dropdown">
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/View_timetable">View Time-Table</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/Add_timetable">Add Time-Table</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Menu area End-->
    <!-- Mobile Menu start -->
    <div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul class="mobile-menu-nav">
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Admin_Controller/index">Dashboard <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#demo" href="">Attendence <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="demo" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Student_Controller/student_attendence">Student Attendence</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teacher_attendence">Teacher Attendece</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#class1" href="">Class <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="class1" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Class_Controller/class_page">View Class</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Class_Controller/Add_class">Add Class</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Student_Controller/parents_page">Parents <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Tablesmob" href="">Sections <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Tablesmob" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Section_Controller/Section_page">View Section</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Section_Controller/Add_section">Add Section</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Tablesmob" href="">Students <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Tablesmob" class="collapse dropdown-header-top">
                                       <li><a href="<?php echo base_url(); ?>Student_Controller/student_admission">Student Admission</a>
                                       </li>
                                       <li><a href="<?php echo base_url(); ?>Student_Controller/view_students">View Students</a>
                                       </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Appviewsmob" href="">Subjects <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Appviewsmob" class="collapse dropdown-header-top">
                                         <li><a href="<?php echo base_url(); ?>Subject_Controller/View_Subjects">View Subjects</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Subject_Controller/Add_Subjects">Add Subjects</a>
                                </li>
                                    </ul>
                                </li>
                                 <li><a data-toggle="collapse" data-target="#teacher1" href="">Teachers <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="teacher1" class="collapse dropdown-header-top">
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Teachers_page">View Teachers</a>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>Teacher_Controller/Add_Teacher">Add Teacher</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Pagemob" href="">Time Table <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                    <ul id="Pagemob" class="collapse dropdown-header-top">
                                      <li><a href="<?php echo base_url(); ?>Timetable_Controller/View_timetable">View Time-Table</a>
                                </li>
                                <li><a href="<?php echo base_url(); ?>Timetable_Controller/Add_timetable">Add Time-Table</a>
                                </li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu end -->
    <!-- Basic Form Start -->
    <div class="basic-form-area mg-b-40" style="margin-top: 1rem;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sparkline12-list shadow-reset mg-t-30">
                        <div class="sparkline12-hd">
                            <div class="main-sparkline12-hd">
                                <h1> <span class="glyphicon glyphicon-th-list"></span>  Edit Class </h1>
                            </div>
                        </div>
                        <div class="sparkline12-graph">
                            <div class="basic-login-form-ad">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="all-form-element-inner">
                                            <form action="<?php echo base_url(); ?>Class_Controller/Update_class_to_database" method="Post" enctype="multipart/form-data">
                                                 <?php 
                                     
                                         if($blogs)
                                         { 
                                           foreach($blogs as $welcome)
                                           {                                              
                                         ?>
                                                <div class="form-group-inner">
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <label class="login2 pull-right pull-right-pro">Class Name</label>
                                                        </div>
                                                        <div class="col-lg-5">
                                                            <div class="form-select-list">
                                                                <select class="form-control custom-select-value" name="classname" required="">
                                                                    <option value="<?php echo $welcome->classname; ?>"><?php echo $welcome->classname; ?></option>
                        
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group-inner">
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <label class="login2 pull-right pull-right-pro">Monthly Tuition Fee</label>
                                                        </div>
                                                        <div class="col-lg-5">
                                                            <div class="form-select-list">
                                                                <input type="text" class="form-control basic-ele-mg-b-10" placeholder="monthly tuition fee" value="<?php echo $welcome->monthlyfee; ?>" required="" name="monthlyfee">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                 <div class="form-group-inner">
                                                    <div class="row">
                                                       <div class="col-lg-4">
                                                            <label class="login2 pull-right pull-right-pro">Admission Fee</label>
                                                        </div>
                                                        <div class="col-lg-5">
                                                            <div class="form-select-list">
                                                                <input type="text" class="form-control" value="<?php echo $welcome->admissionfee; ?>" placeholder="admission fee" name="admissionfee" required="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group-inner">
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <label class="login2 pull-right pull-right-pro">Certification Fee</label>
                                                        </div>
                                                        <div class="col-lg-5">
                                                            <div class="form-select-list">
                                                                <input type="text" class="form-control" value="<?php echo $welcome->certificationfee; ?>" placeholder="certification fee" required="" name="certificationfee">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group-inner">
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <label class="login2 pull-right pull-right-pro">Exam Fee</label>
                                                        </div>
                                                        <div class="col-lg-5">
                                                            <div class="form-select-list">
                                                                <input type="text" class="form-control basic-ele-mg-b-10" value="<?php echo $welcome->examfee; ?>" placeholder="exam fee " name="examfee" required="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group-inner">
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <label class="login2 pull-right pull-right-pro">Due Date</label>
                                                        </div>
                                                        <div class="col-lg-5">
                                                            <div class="form-select-list">
                                                                <input type="date" class="form-control basic-ele-mg-b-10" value="<?php echo $welcome->duedate; ?>"  name="duedate" required="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group-inner">
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <label class="login2 pull-right pull-right-pro">Note</label>
                                                        </div>
                                                        <div class="col-lg-5">
                                                            <div class="form-select-list">
                                                                <textarea class="col-lg-12" name="note"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group-inner">
                                                    <div class="login-btn-inner">
                                                        <div class="row">
                                                            <div class="col-lg-5"></div>
                                                            <div class="col-lg-7">
                                                                <div class="login-horizental cancel-wp pull-left">
                                                                    <button class="btn btn-sm btn-primary login-submit-cs" type="submit">Update Class</button>
                                                                    <a href="<?php echo base_url(); ?>Admin_Controller/cancel"><input type="button" class="btn btn-white" value="cancel"></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                                   }
                                        }
                                       ?>
                                            </form>
                                        </div>
                                        <div class="alert alert-warning alert-mg-b" role="alert"><strong>Instruction!</strong> Please Add Teachers Before Adding Class</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Basic Form End-->
    <!-- Footer Start-->
    <div class="footer-copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-copy-right">
                        <p>Copyright &#169; 2018 KDS All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
    <!-- Chat Box Start-->
    <div class="chat-list-wrap">
        <div class="chat-list-adminpro">
            <div class="chat-button">
                <span data-toggle="collapse" data-target="#chat" class="chat-icon-link"><i class="fa fa-comments"></i></span>
            </div>
            <div id="chat" class="collapse chat-box-wrap shadow-reset animated zoomInLeft">
                <div class="chat-main-list">
                    <div class="chat-heading">
                        <h2>Messanger</h2>
                    </div>
                    <div class="chat-content chat-scrollbar">
                        <div class="author-chat">
                            <h3>Monica <span class="chat-date">10:15 am</span></h3>
                            <p>Hi, what you are doing and where are you gay?</p>
                        </div>
                        <div class="client-chat">
                            <h3>Mamun <span class="chat-date">10:10 am</span></h3>
                            <p>Now working in graphic design with coding and you?</p>
                        </div>
                        <div class="author-chat">
                            <h3>Monica <span class="chat-date">10:05 am</span></h3>
                            <p>Practice in programming</p>
                        </div>
                        <div class="client-chat">
                            <h3>Mamun <span class="chat-date">10:02 am</span></h3>
                            <p>That's good man! carry on...</p>
                        </div>
                    </div>
                    <div class="chat-send">
                        <input type="text" placeholder="Type..." />
                        <span><button type="submit">Send</button></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Chat Box End-->
    <!-- jquery
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/counterup/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/waypoints.min.js"></script>
    <!-- modal JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/modal-active.js"></script>
    <!-- icheck JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/icheck/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/icheck/icheck-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>
</body>

</html>