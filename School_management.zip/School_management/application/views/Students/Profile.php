<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>KDS SCHOOL MANAGEMENT SYSTEM</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>/assets/img/favicon.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/animate.css">
    <!-- jvectormap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jvectormap/jquery-jvectormap-2.0.3.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-editable.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/normalize.css">
    <!-- charts CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/c3.min.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/responsive.css">
    <style type="text/css">
        .fixed-table-body {
                      overflow-x: auto;
                      overflow-y: auto;
                      height: auto;
                       }
        #img {
              max-width: 100%;
              height: 130px;
           }
td{
    text-align: left;
}
    </style>
    <!-- modernizr JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <div class="header-top-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="admin-logo">
                        <a href="<?php echo base_url(); ?>Admin_Controller/index"><img src="<?php echo base_url(); ?>/assets/img/logo/final_logo.png" alt="" />
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-sm-0 col-xs-12">
                </div>
                <div class="col-lg-4 col-md-9 col-sm-6 col-xs-12">
                    <div class="header-right-info">
                        <ul class="nav navbar-nav mai-top-nav header-right-menu">
                             <li class="nav-item dropdown">
                                <a href="" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><span class="adminpro-icon adminpro-chat-pro"></span><span class="indicator-ms"></span></a>
                                <div role="menu" class="author-message-top dropdown-menu animated flipInX">
                                    <div class="message-single-top">
                                        <h1>Message</h1>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                    <span class="adminpro-icon adminpro-user-rounded header-riht-inf"></span>
                                    <span class="admin-name">
                                     <?php 
                                        if($data=$this->session->userdata('user'))
                                        echo $data['studentname'];
                                     ?>
                                     </span>
                                    <span class="author-project-icon adminpro-icon adminpro-down-arrow"></span>
                                </a>
                                <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated flipInX">
                                    <li><a href="<?php echo base_url(); ?>Login_Students_Controller/index""><span class="adminpro-icon adminpro-user-rounded author-log-ic"></span>My Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Login_Students_Controller/Edit_Profile"><span class="adminpro-icon adminpro-checked-pro author-log-ic"></span>Edit Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Login_Students_Controller/logout"><span class="adminpro-icon adminpro-locked author-log-ic"></span>Log Out</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header top area end-->
    <!-- Main Menu area start-->
    <div class="main-menu-area mg-t-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs custom-menu-wrap">
                        <li class="active shadow-reset" ><a href="<?php echo base_url(); ?>Login_Students_Controller/index"><span class="glyphicon glyphicon-user"></span>  Profile</a>
                        </li>
                        <li><a href="<?php echo base_url(); ?>Login_Students_Controller/Attendence"><span class="glyphicon glyphicon-calendar"></span>  Attendence</a>
                        </li>
                        <li><a href="<?php echo base_url(); ?>Login_Students_Controller/Class1"> <span class="glyphicon glyphicon-th-list"></span>  Class</a>
                        </li>
                        <li><a href="<?php echo base_url(); ?>Login_Students_Controller/Subjects"><span class="glyphicon glyphicon-book"></span>  Subjects</a>
                        </li>                        
                        <li><a href="<?php echo base_url(); ?>Login_Students_Controller/Teachers"><i class='fas fa-user-friends' style='font-size:20px'></i>  Teachers</a>
                        </li>
                        <li><a href="<?php echo base_url(); ?>Login_Students_Controller/Time_Table"><span class="glyphicon glyphicon-calendar"></span>  Time Table</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Menu area End-->
    <!-- Mobile Menu start -->
    <div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul class="mobile-menu-nav">
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/index">Profile <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Attendence">Attendence <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Class1">Class <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Subjects">Subjects <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Teachers">Teachers <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Time_Table">Time Table <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu end -->
    <br>
     <!-- Breadcome start-->
    <div class="breadcome-area mg-b-30">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                        <div class="breadcome-heading">
                            <h2>Student Profile</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcome End-->
    <div class="user-profile-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="user-profile-wrap shadow-reset">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="row">
                                    <div class="col-lg-3">
                                        <div class="user-profile-img">
                                            <?php 
                                               if($data=$this->session->userdata('user'))
                                                $file = $data['file'];
                                            ?>
                                             <img id="img" src="<?php echo base_url('studentsphoto/'.$file); ?>" height="500px" width="200px" alt="" />
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="user-profile-content">
                                            <h2>
                                                <?php 
                                                  if($data=$this->session->userdata('user'))
                                                  echo $data['studentname'];
                                                ?>
                                            </h2>
                                             <p class="profile-founder"> <?php if($data=$this->session->userdata('user'))
                                                  echo $data['rollno']; ?></strong>
                                            </p>
                                            <p class="profile-des"><?php if($data=$this->session->userdata('user'))
                                                  echo $data['description']; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="user-profile-social-list">
                                    <table class="table small m-b-xs">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <strong>Parent Name</strong> 
                                                </td>
                                                <td>
                                                  <?php if($data=$this->session->userdata('user'))
                                                  echo $data['parentname']; ?>
                                                </td>

                                            </tr>
                                            <tr>
                                                <td>
                                                    <strong>Phone Number</strong> 
                                                </td>
                                                <td>
                                                   <?php if($data=$this->session->userdata('user'))
                                                  echo $data['phonenumber']; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <strong>Class and Section</strong> 
                                                </td>
                                                <td>
                                                    <?php if($data=$this->session->userdata('user'))
                                                  echo $data['classname']; ?> &nbsp &nbsp &nbsp <?php if($data=$this->session->userdata('user'))
                                                  echo $data['section']; ?> Section
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="analytics-sparkle-line user-profile-sparkline">
                                    <div class="analytics-content">
                                        <h5>Visits in last 24h</h5>
                                        <h2 class="counter">49</h2>
                                        <div id="sparkline22"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="user-prfile-activity-area mg-b-40 mg-t-30">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                   <div class="user-profile-about shadow-reset">
                        <h2>Student Current Progress</h2>
                    </div>
                    <div class="analytics-adminpro-wrap shadow-reset mg-t-30">
                        <div class="skill-content-3 analytics-adminpro analytics-adminpro3">
                            <div class="skill">
                                <div class="progress progress-bt">
                                    <div class="lead-content">
                                        <h3><span class="counter">80</span>%</h3>
                                        <p>Academics</p>
                                    </div>
                                    <div class="progress-bar wow fadeInLeft" data-progress="80%" style="width: 80%;" data-wow-duration="1.5s" data-wow-delay="1.2s"><span>80%</span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="analytics-adminpro-wrap shadow-reset mg-t-30">
                        <div class="skill-content-3 analytics-adminpro">
                            <div class="skill">
                                <div class="progress">
                                    <div class="lead-content">
                                        <h3><span class="counter">95</span>%</h3>
                                        <p>Sports</p>
                                    </div>
                                    <div class="progress-bar wow fadeInLeft" data-progress="95%" style="width: 95%;" data-wow-duration="1.5s" data-wow-delay="1.2s"> <span>95%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="analytics-adminpro-wrap shadow-reset mg-t-30">
                        <div class="skill-content-3 analytics-adminpro analytics-adminpro4">
                            <div class="skill">
                                <div class="progress">
                                    <div class="lead-content">
                                        <h3><span class="counter">85</span>%</h3>
                                        <p>Extra Curicular Activities</p>
                                    </div>
                                    <div class="progress-bar wow fadeInLeft" data-progress="85%" style="width: 85%;" data-wow-duration="1.5s" data-wow-delay="1.2s"><span>85%</span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="analytics-adminpro-wrap profile-res-mg-b-30 shadow-reset mg-t-30">
                        <div class="skill-content-3 analytics-adminpro analytics-adminpro2">
                            <div class="skill">
                                <div class="progress progress-bt">
                                    <div class="lead-content">
                                        <h3><span class="counter">93</span>%</h3>
                                        <p>Leadership</p>
                                    </div>
                                    <div class="progress-bar wow fadeInLeft" data-progress="93%" style="width: 93%;" data-wow-duration="1.5s" data-wow-delay="1.2s"><span>93%</span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="post-user-profile-awrap shadow-reset">
                        <div class="user-profile-post">
                            <div class="row">
                               
                            </div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="profile-user-post-content">
                                       <h4> <strong><span class="glyphicon glyphicon-user"></span> Student Complete Information</strong></h4>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="user-profile-comment-list">
                            <div class="sparkline8-graph">
                     <!--        <div class="datatable-dashv1-list custom-datatable-overright"> -->
                                <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                       <thead></thead>
                                       <tbody>
                                        <tr>
                                            <td></td>
                                            <th data-field="Parent Name " >Parent Name</th>
                                            <td> <?php if($data=$this->session->userdata('user'))
                                                  echo $data['parentname']; ?></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <th data-field="Parent Name " >Class</th>
                                            <td> <?php if($data=$this->session->userdata('user'))
                                                  echo $data['classname']; ?></td>
                                        </tr>
                                         <tr>
                                            <td></td>
                                            <th data-field="Gender" >Gender </th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['gender']; ?></td>
                                        </tr>
                                         <tr>
                                            <td></td>
                                            <th data-field="Student Name" >Blood Group</th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['bloodgroup']; ?></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <th data-field="Student Name" >Present Address</th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['presentadd']; ?></td>
                                        </tr>
                                         <tr>
                                            <td></td>
                                            <th data-field="Student Name" >Permanent Address</th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['permanentadd']; ?></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <th data-field="Student Name" >Religion</th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['religion']; ?></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <th data-field="Student Name" >Student Email</th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['studentemail']; ?></td>
                                        </tr>
                                         <tr>
                                            <td></td>
                                            <th data-field="Student Name" >Parent Email</th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['parentemail']; ?></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <th data-field="Dob">Dob </th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['dob']; ?></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <th data-field="Admission Date" >Admission Date</th>
                                            <td><?php if($data=$this->session->userdata('user'))
                                                  echo $data['admissiondate']; ?></td>
                                        </tr>
                                    </tbody>
                                </table><!-- 
                            </div> -->
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Start-->
    <div class="footer-copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-copy-right">
                        <p>Copyright &#169; 2018 KDS All rights reserved. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
    <!-- jquery
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/counterup/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/waypoints.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/counterup-active.js"></script>
    <!-- peity JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/peity/jquery.peity.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/peity/peity-active.js"></script>
    <!-- sparkline JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.tooltip.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.spline.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.resize.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/flot-active.js"></script>
    <!-- map JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/map/raphael.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/jquery.mapael.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/france_departments.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/world_countries.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/usa_states.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/map-active.js"></script>
    <!-- data table JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/tableExport.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/data-table-active.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-editable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-editable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/colResizable-1.5.source.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-export.js"></script>
    <!-- switcher JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/switcher/styleswitch.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/switcher/switch-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>
</body>

</html>