<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>KDS SCHOOL MANAGEMENT SYSTEM</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>/assets/img/favicon.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/animate.css">
    <!-- jvectormap CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/jvectormap/jquery-jvectormap-2.0.3.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/data-table/bootstrap-editable.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/normalize.css">
    <!-- charts CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/c3.min.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/responsive.css">
    <style type="text/css">
        .fixed-table-body {
    overflow-x: auto;
    overflow-y: auto;
    height: auto;
}
#mon,#tue,#wed,#thu,#fri,#sat{
        background-color: white;
        font-weight: bold;
       }
#View {
            background-color: #E6F4F9;
        }
    </style>
    <!-- modernizr JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <div class="header-top-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="admin-logo">
                        <a href="<?php echo base_url(); ?>Admin_Controller/index"><img src="<?php echo base_url(); ?>/assets/img/logo/final_logo.png" alt="" />
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-sm-0 col-xs-12">
                </div>
                <div class="col-lg-4 col-md-9 col-sm-6 col-xs-12">
                    <div class="header-right-info">
                        <ul class="nav navbar-nav mai-top-nav header-right-menu">
                             <li class="nav-item dropdown">
                                <a href="" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><span class="adminpro-icon adminpro-chat-pro"></span><span class="indicator-ms"></span></a>
                                <div role="menu" class="author-message-top dropdown-menu animated flipInX">
                                    <div class="message-single-top">
                                        <h1>Message</h1>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                    <span class="adminpro-icon adminpro-user-rounded header-riht-inf"></span>
                                    <span class="admin-name">
                                     <?php 
                                        if($data=$this->session->userdata('user'))
                                        echo $data['studentname'];
                                     ?>
                                     </span>
                                    <span class="author-project-icon adminpro-icon adminpro-down-arrow"></span>
                                </a>
                                <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated flipInX">
                                    <li><a href="<?php echo base_url(); ?>Login_Students_Controller/index""><span class="adminpro-icon adminpro-user-rounded author-log-ic"></span>My Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Login_Students_Controller/Edit_Profile"><span class="adminpro-icon adminpro-checked-pro author-log-ic"></span>Edit Profile</a>
                                    </li>
                                    <li><a href="<?php echo base_url(); ?>Login_Students_Controller/logout"><span class="adminpro-icon adminpro-locked author-log-ic"></span>Log Out</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header top area end-->
    <!-- Main Menu area start-->
    <div class="main-menu-area mg-t-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs custom-menu-wrap">
                        <li  ><a href="<?php echo base_url(); ?>Login_Students_Controller/index"><span class="glyphicon glyphicon-user"></span> Profile</a>
                        </li>
                        <li ><a href="<?php echo base_url(); ?>Login_Students_Controller/Attendence"><span class="glyphicon glyphicon-calendar"></span> Attendence</a>
                        </li>
                        <li ><a href="<?php echo base_url(); ?>Login_Students_Controller/Class1"> <span class="glyphicon glyphicon-th-list"></span> Class</a>
                        </li>
                        <li ><a href="<?php echo base_url(); ?>Login_Students_Controller/Subjects"><span class="glyphicon glyphicon-book"></span> Subjects</a>
                        </li>                        
                        <li ><a href="<?php echo base_url(); ?>Login_Students_Controller/Teachers"><i class='fas fa-user-friends' style='font-size:20px'></i> Teachers</a>
                        </li>
                        <li class="active shadow-reset"><a href="<?php echo base_url(); ?>Login_Students_Controller/Time_Table"><span class="glyphicon glyphicon-calendar"></span> Time Table</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Menu area End-->
    <!-- Mobile Menu start -->
    <div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul class="mobile-menu-nav">
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/index">Profile <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Attendence">Attendence <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Class1">Class <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Subjects">Subjects <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Teachers">Teachers <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#Charts" href="<?php echo base_url(); ?>Login_Students_Controller/Time_Table">Time Table <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                </li>
                                
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu end -->
    <br>
     <!-- Breadcome start-->
    <div class="breadcome-area mg-b-30">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                        <div class="breadcome-heading">
                            <h2><?php 
                                        if($data=$this->session->userdata('user'))
                                        echo $data['classname'];
                                    echo $data['section'];
                                     ?> Class Subjects</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcome End-->
    <!-- Data table area Start-->
  <div class="admin-dashone-data-table-area mg-b-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sparkline8-list shadow-reset">
                        <div class="sparkline8-hd">
                            <div class="main-sparkline8-hd">
                                <div style="display: none;" class="alert alert-success"> 
                                 <div>All records were processed correctly!</div>
                               </div>
                                <div style="display: none;" class="alert alert-failure"> 
                                 <div>All records were not processed correctly!</div>
                               </div>
                               <h1><span class="glyphicon glyphicon-calendar"></span> 
                                    Time-Table for Class 
                                    <?php  
                                      if($data=$this->session->userdata('user'))
                                        echo $data['classname']; 
                                    ?>
                                    " <?php  
                                       if($data=$this->session->userdata('user'))
                                        echo $data['section']; ?> " Section
                                </h1>
                            </div>
                        </div>
                        <div class="sparkline8-graph">
                            <div class="datatable-dashv1-list custom-datatable-overright">
                                <div id="toolbar">
                                    <select class="form-control">
                                        <option value="">Export Basic</option>
                                        <option value="all">Export All</option>
                                        <option value="selected">Export Selected</option>
                                    </select>
                                </div>
                                <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th data-field="state"><center>Period 1<br> 9:30.AM-10:30.AM</center> </th>
                                            <th data-field="Sl No"><center>Period 2<br>10:30.AM-11:00.AM</center></th>
                                            <th data-field="Class" ><center>Period 3<br>11:30.AM-12:30.PM</center></th>
                                            <th data-field="Section" ><center>Period 4<br>12:30.PM-1:30.PM</center></th>
                                            <th data-field="Action"><center>Period 5<br>2:00.PM-3:00.PM</center></th>
                                            <th><center>Period 6<br>3:00.PM-4:00.PM</center></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                          <td id="mon">MONDAY</td>
                                          <?php if ($blogs) 
                                          {      
                                                 foreach ($blogs as $key) 
                                                 { 
                                           ?>      
                                          <td id="View">
                                          <?php echo $key->subjectname;?><br>
                                           <?php echo $key->teachername;?><br>
                                          <?php echo $key->roomno;?>
                                          </td>
                                          <?php 
                                                 }  
                                          } 
                                          ?>
                                        </tr> 
                                        
                                        <tr>
                                          <td id="tue">TUESDAY</td>
                                          <?php if ($blogs1) 
                                          {
                                                 foreach ($blogs1 as $key) 
                                                 {
                                           ?>      
                                          <td id="View">
                                            <?php echo $key->subjectname;?><br>
                                            <?php echo $key->teachername;?><br>
                                            <?php echo $key->roomno;?>
                                          </td>
                                          <?php 
                                                 }  
                                          } 
                                          ?>
                                        </tr> 
                                        
                                        <tr>
                                          <td id="wed">WEDNESDAY</td>
                                          <?php if ($blogs2) 
                                          {
                                                 foreach ($blogs2 as $key) 
                                                 {
                                           ?>      
                                          <td id="View">
                                            <?php echo $key->subjectname;?><br>
                                            <?php echo $key->teachername;?><br>
                                            <?php echo $key->roomno;?>
                                          </td>
                                          <?php 
                                                 }  
                                          } 
                                          ?>
                                        </tr> 
                                        
                                        <tr>
                                          <td id="thu">THURSDAY</td>
                                          <?php if ($blogs3) 
                                          {
                                                 foreach ($blogs3 as $key) 
                                                 {
                                           ?>      
                                          <td id="View">
                                            <?php echo $key->subjectname;?><br>
                                            <?php echo $key->teachername;?><br>
                                            <?php echo $key->roomno;?>
                                          </td>
                                          <?php 
                                                 }  
                                          } 
                                          ?>
                                        </tr> 
                                        
                                        <tr>
                                          <td id="fri">FRIDAY</td>
                                          <?php if ($blogs4) 
                                          {
                                                 foreach ($blogs4 as $key) 
                                                 {
                                           ?>      
                                          <td id="View">
                                            <?php echo $key->subjectname;?><br>
                                            <?php echo $key->teachername;?><br>
                                            <?php echo $key->roomno;?>
                                          </td>
                                          <?php 
                                                 }  
                                          } 
                                          ?>
                                        </tr> 
                                        
                                        <tr>
                                          <td id="sat">SATURDAY</td>
                                          <?php if ($blogs5) 
                                          {
                                                 foreach ($blogs5 as $key) 
                                                 {
                                           ?>      
                                          <td id="View">
                                            <?php echo $key->subjectname;?><br>
                                            <?php echo $key->teachername;?><br>
                                            <?php echo $key->roomno;?>
                                          </td>
                                          <?php 
                                                 }  
                                          } 
                                          ?>
                                        </tr> 
                                        

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Data table area End-->
        <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <!-- Footer Start-->
    <div class="footer-copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-copy-right">
                        <p>Copyright &#169; 2018 KDS All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
    <!-- jquery
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/counterup/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/waypoints.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/counterup/counterup-active.js"></script>
    <!-- peity JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/peity/jquery.peity.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/peity/peity-active.js"></script>
    <!-- sparkline JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.tooltip.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.spline.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.resize.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/flot/flot-active.js"></script>
    <!-- map JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/map/raphael.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/jquery.mapael.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/france_departments.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/world_countries.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/usa_states.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/map/map-active.js"></script>
    <!-- data table JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/tableExport.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/data-table-active.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-editable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-editable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/colResizable-1.5.source.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/data-table/bootstrap-table-export.js"></script>
    <!-- switcher JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/switcher/styleswitch.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/switcher/switch-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>
</body>

</html>