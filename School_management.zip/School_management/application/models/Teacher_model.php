<?php
	class Teacher_model extends CI_Model {
		function __construct(){
			parent::__construct(); 
			$this->load->database();
		}
	    public function get_teachers_details()
	    {
	    	$query = $this->db->get('teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_single_teachers_details($teachername)
	    {
	    	$this->db->where('teachername',$teachername);
	    	$query = $this->db->get('teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_classes_details()
	    {
	    	$this->db->distinct();
            $this->db->select('classname');
	    	$query = $this->db->get('sections');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    }
         public function check_for_attendence_is_already_marked($teachername, $phonenumber, $email, $attendencedate)
         {
         	$this->db->where('teachername', $teachername);
            $this->db->where('phonenumber', $phonenumber);
	    	$this->db->where('email', $email);
	    	$this->db->where('attendencedate', $attendencedate);
	    	$query = $this->db->get('teachers_attendence');
		    if($query->num_rows() > 0){
			  return true;
		    }else{
			  return false;
		    }	
         }
         public function update_attendence_to_database($teachername, $phonenumber, $email, $attendencedate, $present, $absent)
         {
            $this->db->where('teachername', $teachername);
            $this->db->where('phonenumber', $phonenumber);
	    	$this->db->where('email', $email);
	    	$this->db->where('attendencedate', $attendencedate);
         	$this->db->update('teachers_attendence', array('present'=>$present, 'absent'=>$absent));
         	  if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
         }
         public function Add_attendence_to_database($teachername, $phonenumber, $email, $attendencedate, $present, $absent)
         {
         	$this->db->insert('teachers_attendence', array('teachername'=>$teachername, 'phonenumber'=>$phonenumber, 'email'=>$email, 'attendencedate'=>$attendencedate, 'present'=>$present, 'absent'=>$absent));
         	  if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
         }

	    public function add_teacher($teachername, $subject, $phonenumber, $presentadd, $permanentadd, $gender, $bloodgroup, $religion, $dob, $joiningdate, $role,  $salarytype, $salary, $email, $teacherpassword, $fb, $twt, $insta, $linkedin, $description, $file, $created_at)
	    {
	    	$this->db->insert('teachers', array('teachername'=>$teachername, 'subject'=>$subject, 'phonenumber'=>$phonenumber, 'presentadd'=>$presentadd, 'permanentadd'=>$permanentadd, 'gender'=>$gender, 'bloodgroup'=>$bloodgroup, 'religion'=>$religion, 'dob'=>$dob,'joiningdate'=>$joiningdate, 'role'=>$role,'salarytype'=>$salarytype,'salary'=>$salary, 'email'=>$email, 'teacherpassword'=>$teacherpassword, 'fb'=>$fb, 'twt'=>$twt, 'insta'=>$insta, 'linkedin'=>$linkedin, 'description'=>$description, 'file'=>$file, 'created_at'=>$created_at));
		    if($this->db->affected_rows() > 0)
		    {
			  return true; 
		    }else
		    {
			  return false;
		    }
	    }
	    public function update_teacher($teachername, $subject, $phonenumber, $presentadd, $permanentadd, $gender, $bloodgroup, $religion, $dob, $joiningdate, $role,  $salarytype, $salary, $email, $teacherpassword, $fb, $twt, $insta, $linkedin, $description, $file, $created_at)
	    {
	    	$this->db->where('teachername', $teachername);
	    	$this->db->update('teachers', array('teachername'=>$teachername, 'subject'=>$subject, 'phonenumber'=>$phonenumber, 'presentadd'=>$presentadd, 'permanentadd'=>$permanentadd, 'gender'=>$gender, 'bloodgroup'=>$bloodgroup, 'religion'=>$religion, 'dob'=>$dob,'joiningdate'=>$joiningdate, 'role'=>$role,'salarytype'=>$salarytype,'salary'=>$salary, 'email'=>$email, 'teacherpassword'=>$teacherpassword, 'fb'=>$fb, 'twt'=>$twt, 'insta'=>$insta, 'linkedin'=>$linkedin, 'description'=>$description, 'file'=>$file, 'created_at'=>$created_at));
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function Get_Single_Teacher_Detail($teachername)
	    {
	    	$this->db->where('teachername', $teachername);
	    	$query = $this->db->get('teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function Delete_Teacher($teachername)
		{
         	$this->db->where('teachername', $teachername);
		    $this->db->delete('teachers');
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	}
?>