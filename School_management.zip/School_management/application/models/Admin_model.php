<?php
	class Admin_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database(); 
		}
		public function update_profile($uname,$email, $phonenumber, $permanentadd, $presentadd, $designation, $gender, $bloodgroup, $religion, $dob, $joiningdate, $description, $hash_pass, $file )
		{
		    $this->db->update('admin', array('uname'=>$uname, 'email'=>$email, 'phonenumber'=>$phonenumber, 'permanentadd'=>$permanentadd, 'presentadd'=>$presentadd, 'designation'=>$designation, 'gender'=>$gender, 'bloodgroup'=>$bloodgroup, 'religion'=>$religion, 'dob'=>$dob, 'joiningdate'=>$joiningdate, 'description'=>$description, 'pw'=>$hash_pass, 'file'=>$file ));
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function get_admin_details() 
	    {
	    	$query = $this->db->get('admin');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_students_details()
	    {
	    	$query = $this->db->get('students');
	    	$count = $query->num_rows();
		    if($count > 0){
			  return $count;
		    }else{
			  return false;
		    }
	    }
	    public function get_classes_details()
	    {
	    	$query = $this->db->get('classes');
	    	$count = $query->num_rows();
		    if($count > 0){
			  return $count;
		    }else{
			  return false;
		    }
	    }
	    public function get_teachers_details()
	    {
	    	$query = $this->db->get('teachers');
	    	$count = $query->num_rows();
		    if($count > 0){
			  return $count;
		    }else{
			  return false;
		    }
	    }
	    public function add_event($name,$desc,$start_date,$end_date)
	    {
	    	$this->db->insert('todolist',array("title" => $name,"description" => $desc,"start" => $start_date,"end" => $end_date));
	    	if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function get_events()
	    {
            $query = $this->db->get('todolist');
	    	$count = $query->num_rows();
		    if($count > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	}
?>