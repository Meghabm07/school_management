<?php
	class Timetable_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
		public function get_timetable_details()
	    {
	    	$this->db->distinct();
            $this->db->select('classname');
            $this->db->select('sectionname');
	    	$query = $this->db->get('timetable');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    } 
	    public function verify_if_already_time_table_exits($classname,$section)
	    {
	    	$this->db->where('classname', $classname);
	    	$this->db->where('sectionname',$section);
	    	$query = $this->db->get('timetable');
		    if($query->num_rows() > 0)
		    {
			  return false;
		    }
		    else
		    {
			  return true;
		    }
	    }
	    public function get_single_timetable_details($classname,$section)
	    {
	    	$this->db->where('classname', $classname);
	    	$this->db->where('sectionname',$section);
	    	$query = $this->db->get('timetable');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_teachers_names()
	    {
	    	$query = $this->db->get('teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_class_details()
	    {
	    	$this->db->distinct();
            $this->db->select('classname');
	    	$query = $this->db->get('sections');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    }
	    public function get_subjects_details()
	    {
	    	$query = $this->db->get('subjects1');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
        public function fetch_section($classname, $section)
        {
          $this->db->where('classname', $classname);
          $this->db->order_by('section', 'ASC');
          $query = $this->db->get('sections');
          $output = '<option value="">Select section</option>';
          foreach($query->result() as $row)
          {
            $output .= '<option id="section" value="'.$row->section.'">'.$row->section.'</option>';
          }
           return $output;
         }
         public function verify_timetable_already_exits($classname,$section,$period,$day)
         {
          $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $section);
	   	  $this->db->where('period', $period);
	   	  $this->db->where('day', $day);

          $query = $this->db->get('timetable');

          if($query->num_rows() == 0){
			  return true;
		    }else{
			  return false;
		    }
         }
         public function Add_timetable($classname, $section, $subjectname, $teachername,$day, $roomno, $period)
         {
         	$this->db->insert('timetable', array('classname'=>$classname, 'sectionname'=>$section, 'subjectname'=>$subjectname, 'teachername'=>$teachername, 'day'=>$day, 'roomno'=>$roomno, 'period'=>$period));
         	  if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
         }
         public function Update_timetable($classname, $section, $subjectname, $teachername,$day, $roomno, $period)
         {
         	$this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $section);
	   	  $this->db->where('period', $period);
	   	  $this->db->where('day', $day);
         	$this->db->update('timetable', array('subjectname'=>$subjectname, 'teachername'=>$teachername, 'roomno'=>$roomno));
         	 if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
         }
	   public function get_monday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Monday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_tuesday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Tuesday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_wednesday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Wednesday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_thursday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Thursday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_friday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Friday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_saturday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Saturday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }


	    public function Delete_Class($classname,$sectionname)
		{
			$this->db->where('classname', $classname);
         	$this->db->where('sectionname', $sectionname);
		    $this->db->delete('timetable');
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
}
?>