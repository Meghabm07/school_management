<?php
	class Login_Students_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
	    public function Update_Profile($studentname,$rollno,$newpassword,$file)
	    {
	    	$this->db->where('studentname',$studentname);
	    	$this->db->where('rollno',$rollno);
	    	$this->db->update('students', array('studentpassword'=>$newpassword,'file'=>$file));
         	  if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    { 
			  return false;
		    }
	    }
	    public function get_attendence_present_details($studentname, $parentname, $classname, $section, $rollno)
	    {
	    	$this->db->where('studentname',$studentname);
	    	$this->db->where('parentname',$parentname);
	    	$this->db->where('classname',$classname);
	    	$this->db->where('sectionname',$section);
            $this->db->where('rollno',$rollno);
	    	$this->db->where('present','P');
	    	$query = $this->db->get('students_attendence');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_attendence_absent_details($studentname, $parentname, $classname, $section, $rollno)
	    {
	    	$this->db->where('studentname',$studentname);
	    	$this->db->where('parentname',$parentname);
	    	$this->db->where('classname',$classname);
	    	$this->db->where('sectionname',$section);
            $this->db->where('rollno',$rollno);
	    	$this->db->where('absent','A');
	    	$query = $this->db->get('students_attendence');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
		public function get_Class_details($classname, $section)
	    {
	    	$this->db->where('classname',$classname);
	    	$this->db->where('section',$section);
	    	$query = $this->db->get('students');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    }
		public function get_Subject_details($classname)
	    {
	    	$this->db->where('classname',$classname);
	    	$query = $this->db->get('subjects1');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    }
		public function get_Teachers_details($classname)
	    {
	    	$query = $this->db->get('Teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    }
       public function get_monday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Monday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_tuesday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Tuesday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_wednesday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Wednesday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_thursday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Thursday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_friday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Friday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	   public function get_saturday_timetable_details($classname,$sectionname)
	   {
	   	  $this->db->where('classname', $classname);
	   	  $this->db->where('sectionname', $sectionname);
	   	  $this->db->where('day', 'Saturday');
          $this->db->order_by('period', 'ASC');
          $query = $this->db->get('timetable');
          if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	   }
	
}
?>