<?php
	class Class_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
		public function get_classes_details()
	    {
	    	$query = $this->db->get('classes');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function Get_Single_Class_Detail($classname)
	    {
	    	$this->db->where('classname', $classname);
	    	$query = $this->db->get('classes');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_teachers_names()
	    {
	    	$query = $this->db->get('teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function verify_class_already_exits($classname)
	    {
	    	$this->db->where('classname', $classname);
	    	$query = $this->db->get('classes');
		    if($query->num_rows() == 0){
			  return true;
		    }else{
			  return false;
		    }
	    }
	    public function add_class($classname, $monthlyfee, $admissionfee, $examfee, $certificationfee,$duedate, $note, $created_at)
	    {
	    	$this->db->insert('classes', array('classname'=>$classname, 'monthlyfee'=>$monthlyfee, 'admissionfee'=>$admissionfee, 'examfee'=>$examfee, 'certificationfee'=>$certificationfee, 'duedate'=>$duedate, 'note'=>$note, 'created_at'=>$created_at));
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function update_class($classname, $monthlyfee, $admissionfee, $examfee, $certificationfee,$duedate, $note, $modified_at)
	    {

	    	$this->db->where('classname', $classname);
		    $this->db->update('classes', array('classname'=>$classname, 'monthlyfee'=>$monthlyfee, 'admissionfee'=>$admissionfee, 'examfee'=>$examfee, 'certificationfee'=>$certificationfee, 'duedate'=>$duedate, 'note'=>$note, 'modified_at'=>$modified_at));
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function Delete_Class($classname)
		{
         	$this->db->where('classname', $classname);
		    $this->db->delete('classes');
		    if($this->db->affected_rows() > 0)
		    {
		      $this->db->where('classname', $classname);
              $this->db->delete('sections');
			  return true;
		    }
		    else
		    {
			  return false;
		    }
	    }
}
?>