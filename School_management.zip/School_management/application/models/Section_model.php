<?php
	class Section_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
	    public function get_Sections_details()
	    {
	    	$query = $this->db->get('sections');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_class_names()
	    {
	    	$query = $this->db->get('classes');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{ 
			  return false;
		    }
	    }
	    public function get_teachers_names()
	    {
	    	$query = $this->db->get('teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_single_Section_details($section,$classname)
	    {
	    	$this->db->where('section', $section);
	    	$this->db->where('classname', $classname);
	    	$query = $this->db->get('sections');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function check_section_already_exits($Sectionname,$class)
	    {
	    	$this->db->where('Section', $Sectionname);
	    	$this->db->where('classname', $class);
	    	$query = $this->db->get('sections');
	    	 if($query->num_rows() == 0){
			  return true;
		    }else{
			  return false;
		    }

	    }
	    public function Add_Sections($Sectionname, $class, $teachername, $description, $created_at)
	    {
	    	$this->db->insert('sections', array('Section'=>$Sectionname, 'classname'=>$class,'teachername'=>$teachername,'description'=>$description,'created_at'=>$created_at));
	         if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function get_teachers_details()
	    {
	    	$query = $this->db->get('teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function update_Sections($section, $classname, $teachername, $description, $modified_at)
	    {
	    	$this->db->where('classname', $classname);
	    	$this->db->where('section', $section);
	    	$this->db->update('sections', array('section'=>$section, 'classname'=>$classname,'teachername'=>$teachername,'description'=>$description,'modified_at'=>$modified_at));
	         if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function Delete_Section($classname,$section)
		{
         	$this->db->where('classname', $classname);
         	$this->db->where('section', $section);
		    $this->db->delete('sections');
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
}
?>