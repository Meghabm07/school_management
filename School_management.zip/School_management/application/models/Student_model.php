<?php
	class Student_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
	    public function get_students_details()
	    {
	    	$query = $this->db->get('students'); 
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    }
	    public function get_single_students_details($rollno)
	    {
            $this->db->where('rollno',$rollno);
	    	$query = $this->db->get('students');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
		public function get_classes_details()
	    {
	    	$this->db->distinct();
            $this->db->select('classname');
	    	$query = $this->db->get('sections');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    }
	    
	    public function fetch_section($classname, $section)
        {
          $this->db->where('classname', $classname);
          $this->db->order_by('section', 'ASC');
          $query = $this->db->get('sections');
          $output = '<option value="">Select section</option>';
          foreach($query->result() as $row)
          {
            $output .= '<option value="'.$row->section.'">'.$row->section.'</option>';
          }
           return $output;
         }
         public function check_for_attendence_is_aleready_marked($rollno, $classname, $studentname, $sectionname, $attendencedate)
         {
         	$this->db->where('rollno', $rollno);
            $this->db->where('classname', $classname);
	    	$this->db->where('sectionname', $sectionname);
	    	$this->db->where('attendencedate', $attendencedate);
	    	$query = $this->db->get('students_attendence');
		    if($query->num_rows() > 0){
			  return true;
		    }else{
			  return false;
		    }	
         }
         public function update_attendence_to_database($rollno, $classname, $studentname, $parentname, $sectionname, $attendencedate, $present, $absent)
         {
            $this->db->where('rollno', $rollno);
            $this->db->where('classname', $classname);
	    	$this->db->where('sectionname', $sectionname);
	    	$this->db->where('attendencedate', $attendencedate);
         	$this->db->update('students_attendence', array('present'=>$present, 'absent'=>$absent));
         	  if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
         }
         public function Add_attendence_to_database($rollno, $classname, $studentname, $parentname, $sectionname, $attendencedate, $present, $absent)
         {
         	$this->db->insert('students_attendence', array('rollno'=>$rollno, 'classname'=>$classname, 'studentname'=>$studentname, 'parentname'=>$parentname, 'sectionname'=>$sectionname, 'attendencedate'=>$attendencedate, 'present'=>$present, 'absent'=>$absent));
         	  if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
         }

	    public function get_single_classes_details($classname,$section)
	    {
	    	$this->db->where('classname', $classname);
	    	$this->db->where('section', $section);
	    	$query = $this->db->get('students');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function Student_Name_Validation($studentname,$parentname)
	    {
	    	 $this->db->select('*'); 
             $this->db->from('students');
             $this->db->where('studentname', $studentname);
             $this->db->where('parentname', $parentname);
             $query = $this->db->get();
             if ($query->num_rows() == 0) {
              return true;
            } else {
              return false;
            }
	    }
	    public function add_students($studentname, $parentname, $dob, $gender, $phonenumber, $presentadd, $permanentadd, $religion, $studentemail, $parentemail, $file, $studentpassword, $parentpassword,  $bloodgroup, $admissiondate, $class, $section,  $description, $created_at)
	    {
	    	$this->db->insert('students', array('studentname'=>$studentname, 'parentname'=>$parentname, 'dob'=>$dob, 'gender'=>$gender, 'phonenumber'=>$phonenumber, 'presentadd'=>$presentadd, 'permanentadd'=>$permanentadd, 'religion'=>$religion, 'studentemail'=>$studentemail, 'parentemail'=>$parentemail, 'file'=>$file, 'studentpassword'=>$studentpassword, 'parentpassword'=>$parentpassword, 'bloodgroup'=>$bloodgroup, 'admissiondate'=>$admissiondate, 'classname'=>$class, 'section'=>$section, 'description'=>$description, 'created_at'=>$created_at));
	         if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function update_student($rollno, $studentname, $parentname, $dob, $gender, $phonenumber, $presentadd, $permanentadd, $religion, $studentemail, $parentemail, $file, $studentpassword, $parentpassword,  $bloodgroup, $admissiondate, $class, $section,  $description, $created_at)
	    {
	    	$this->db->where('rollno', $rollno);
	    	$this->db->update('students', array('studentname'=> $studentname, 'parentname'=>$parentname, 'dob'=>$dob, 'gender'=>$gender, 'phonenumber'=>$phonenumber, 'presentadd'=>$presentadd, 'permanentadd'=>$permanentadd, 'religion'=>$religion, 'studentemail'=>$studentemail, 'parentemail'=>$parentemail, 'file'=>$file, 'studentpassword'=>$studentpassword, 'parentpassword'=>$parentpassword, 'bloodgroup'=>$bloodgroup, 'admissiondate'=>$admissiondate, 'classname'=>$class, 'section'=>$section, 'description'=>$description, 'created_at'=>$created_at));
	         if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function get_parents_details()
	    {
	    	$query = $this->db->get('students');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_single_student_details($rollno)
	    {
	    	$this->db->where('rollno', $rollno);
		    $query = $this->db->get('students');
		     if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function Delete_Student($rollno)
		{
         	$this->db->where('rollno', $rollno);
		    $this->db->delete('students');
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
}
?>