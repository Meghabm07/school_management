<?php
	class Authentication_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
		public function register($email, $uname, $hash_password)
		{
			$query = $this->db->insert('admin', array('email'=>$email, 'uname'=>$uname, 'pw'=>$hash_password));	
		    if($query){
			  return true;
		    }else{
			  return false;
		    }
		}
		public function login($email, $hash_password)
		{
			$query = $this->db->get_where('admin', array('email'=>$email, 'pw'=>$hash_password));
			return $query->row_array();
		}	
		public function studentlogin($email, $password)
		{
			$query1 = $this->db->get_where('students', array('studentemail'=>$email, 'studentpassword'=>$password));
			return $query1->row_array();
		}
	}
?>