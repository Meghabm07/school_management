<?php
	class Subject_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
	    public function get_subjects_details()
	    {
	    	$query = $this->db->get('subjects1'); 
		    if($query->num_rows() > 0){
			  return $query->result(); 
		    }else{
			  return false;
		    }
	    }
	    public function get_single_classes_details($classname)
	    { 
	    	$this->db->where('classname', $classname);
	    	$query = $this->db->get('subjects1');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_classes_details()
	    {
	    	$this->db->distinct();

            $this->db->select('classname');
	    	$query = $this->db->get('sections');

		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    } 
	    }
	    public function get_teacher_details()
	    {
	    	$this->db->distinct('classname');
	    	$query = $this->db->get('teachers');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_class_details()
	    {
	    	$query = $this->db->get('classes');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function Subject_Name_Validation($subjectname)
	    {
	    	 $this->db->select('*'); 
             $this->db->from('subjects1');
             $this->db->where('subjectname', $subjectname);
             $query = $this->db->get();
             if ($query->num_rows() == 0) {
              return true;
            } else {
              return false;
            }
	    }
	    public function Add_subjects($subjectname, $subjectcode, $subjecttype, $class, $teacher, $passmarks, $fullmarks, $description, $created_at)
	    {
	    	$this->db->insert('subjects1', array('subjectname'=>$subjectname, 'subjectcode'=>$subjectcode, 'subjecttype'=>$subjecttype, 'classname'=>$class,'teachername'=>$teacher, 'passmarks'=>$passmarks, 'fullmarks'=>$fullmarks, 'description'=>$description,'created_at'=>$created_at));
	         if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function update_subjects($subjectname, $subjectcode, $subjecttype, $class, $teacher, $passmarks, $fullmarks, $description, $created_at)
	    {
	    	$this->db->where('subjectname', $subjectname);
	    	$this->db->update('subjects1', array('subjectcode'=>$subjectcode, 'subjecttype'=>$subjecttype, 'classname'=>$class,'teachername'=>$teacher, 'passmarks'=>$passmarks, 'fullmarks'=>$fullmarks, 'description'=>$description,'created_at'=>$created_at));
	         if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
	    public function get_parents_details()
	    {
	    	$query = $this->db->get('subjects1');
		    if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function get_single_subject_details($subjectcode)
	    {
	    	$this->db->where('subjectcode', $subjectcode);
		    $query = $this->db->get('subjects1');
		     if($query->num_rows() > 0){
			  return $query->result();
		    }else{
			  return false;
		    }
	    }
	    public function Delete_Subject($subjectname)
		{
         	$this->db->where('subjectname', $subjectname);
		    $this->db->delete('subjects1');
		    if($this->db->affected_rows() > 0)
		    {
			  return true;
		    }else
		    {
			  return false;
		    }
	    }
}
?>