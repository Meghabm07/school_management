<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Timetable_Controller extends CI_Controller {
  
    function __construct()
    {
		parent::__construct();
		$this->load->model('Authentication_model');
		$this->load->model('Timetable_model');
    }
    public function View_timetable() 
	{
      $this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs'] = $this->Timetable_model->get_timetable_details();
		  if($data)
		  { 
            $this->load->view('Admin/Time-Table/View_timetable',$data);
          }
          else
          {
            $this->load->view('dashboard-2');
          }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}	
    public function fetch_section()
    {
        $classname = $this->input->post('classname');
        $section = $this->input->post('section');
        if($classname)
        {
           echo $this->Timetable_model->fetch_section($classname,$section);
        }
  } 	
	public function Add_timetable()
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{			
			 $data['blogs'] = $this->Timetable_model->get_class_details();
             $this->load->view('Admin/Time-Table/Add_timetable',$data);
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Add_timetable_index()
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{	
		  $classname=$_POST['classname'];
		  $section=$_POST['section'];
		  $verify = $this->Timetable_model->verify_if_already_time_table_exits($classname,$section);
		  if($verify)
		  {
		    $data['classname'] = $classname;
		    $data['section'] = $section;
		    $data['blogs'] = $this->Timetable_model->get_single_timetable_details($classname,$section);
		    $data['blogs2'] = $this->Timetable_model->get_teachers_names();
		    $data['blogs1'] = $this->Timetable_model->get_subjects_details();
		    $this->load->view('Admin/Time-Table/Add_timetable_index',$data);
		  }
		  else
		  {
            $this->load->library('session');
        	$this->session->set_flashdata('msg', 'Category added');
            redirect('Timetable_Controller/Add_timetable');
		  }
		}
		else
		{
			redirect('Authentication_Controller/index');
		}
	}
	public function Add_timetable_to_database()
	{
	  $this->load->library('session');
	  if($this->session->userdata('user'))
	  {
		$section = $_POST['section'];
		$classname = $_POST['classname'];
		$period=$_POST['period'];
    	$day=$_POST['day'];
		$verify = $this->Timetable_model->verify_timetable_already_exits($classname,$section,$period,$day);
		if($verify)
		{
    	      $teachername=$_POST['teachername'];
    	      $subjectname=$_POST['subjectname'];
    	      $roomno=$_POST['roomno'];
    	      $created_at = date('Y-m-d H:i:s');
              $data = $this->Timetable_model->Add_timetable($classname, $section, $subjectname, $teachername, $day, $roomno, $period);
		      if($data)
		      {
		       	 $this->View_timetable();
		       	 $data1 = 1;
	             echo json_encode($data1);
		      }else
		      {	
		         redirect('Admin_Controller/index');
	          }
	     }
	     else
	     {
	        $data1 = 0;
	        echo json_encode($data1);
	     }
	   }
	   else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Update_timetable_to_database()
	{
	  $this->load->library('session');
	  if($this->session->userdata('user'))
	  {
		$section = $_POST['section'];
		$classname = $_POST['classname'];
		$period=$_POST['period'];
    	$day=$_POST['day'];
    	$teachername=$_POST['teachername'];
    	$subjectname=$_POST['subjectname'];
    	$roomno=$_POST['roomno'];
    	$created_at = date('Y-m-d H:i:s');
        $data = $this->Timetable_model->Update_timetable($classname, $section, $subjectname, $teachername, $day, $roomno, $period);
        if($data)
        {
         	 $this->View_timetable();
         	 $data1 = 1;
	         echo json_encode($data1);
        }else
        {	
           redirect('Admin_Controller/index');
	    }
	   }
	   else{
			redirect('Authentication_Controller/index');
		}
	}
	public function View_single_timetable($classname,$section)
	{
	    $classname =  $this->uri->segment(3);
        $sectionname =  $this->uri->segment(4);
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['classname'] = $classname;
		  $data['section'] = $sectionname;
		  $data['blogs'] = $this->Timetable_model->get_monday_timetable_details($classname,$sectionname);
          $data['blogs1'] = $this->Timetable_model->get_tuesday_timetable_details($classname,$sectionname);
          $data['blogs2'] = $this->Timetable_model->get_wednesday_timetable_details($classname,$sectionname);
          $data['blogs3'] = $this->Timetable_model->get_thursday_timetable_details($classname,$sectionname);
          $data['blogs4'] = $this->Timetable_model->get_friday_timetable_details($classname,$sectionname);
          $data['blogs5'] = $this->Timetable_model->get_saturday_timetable_details($classname,$sectionname);
          $data['blogs6'] = $this->Timetable_model->get_teachers_names();
		  $data['blogs7'] = $this->Timetable_model->get_subjects_details();
          if($data)
		  {
             $this->load->view('Admin/Time-Table/timetable_format',$data);
	   	  }
		  else
	   	  {
             $this->load->view('dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Delete_timetable()
	{
	    $classname =  $this->uri->segment(3);
        $sectionname =  $this->uri->segment(4);
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data=$this->Timetable_model->Delete_Class($classname,$sectionname);
          if($data)
		  {
             $this->View_timetable();
	   	  }
		  else
	   	  {
             $this->load->view('dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
       
	}

}