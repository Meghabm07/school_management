<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Class_Controller extends CI_Controller {

    function __construct()
    {
		parent::__construct();
		$this->load->model('Authentication_model');
		$this->load->model('Class_model');
    }
    public function class_page()
	{
      $this->load->library('session');
		if($this->session->userdata('user')) 
		{
		  $data['blogs'] = $this->Class_model->get_classes_details();
		  if($data)
		  {
            $this->load->view('Admin/Class/Class_page',$data);
          }
          else
          {
            $this->load->view('dashboard-2');
          }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}	
	public function Add_class()
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{			
			 $data['blogs'] = $this->Class_model->get_teachers_names();
			 $data['blogs1'] = $this->Class_model->get_classes_details();
             $this->load->view('Admin/Class/Add_class',$data);
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Add_class_to_database()
	{
		$classname=$_POST['classname'];
		$verify = $this->Class_model->verify_class_already_exits($classname);
		if($verify)
		{
    	   $monthlyfee=$_POST['monthlyfee'];
    	   $admissionfee=$_POST['admissionfee'];
    	   $examfee=$_POST['examfee'];
    	   $certificationfee=$_POST['certificationfee'];
    	   $duedate=$_POST['duedate'];
    	   $note=$_POST['note'];
    	   $created_at = date('Y-m-d H:i:s');
           $data = $this->Class_model->add_class($classname,  $monthlyfee, $admissionfee, $examfee, $certificationfee, $duedate, $note, $created_at);
		   if($data)
		   {
		   	   $this->load->library('session');
        	   $this->session->set_flashdata('msg', 'Category added');
               redirect('Class_Controller/class_page');
		   }else
		   {	
		     redirect('Admin_Controller/index');
	       }
		}
		else
		{
        	$this->load->library('session');
        	$this->session->set_flashdata('msg', 'Category added');
            redirect('Class_Controller/Add_class');
        	
        }
	}
	public function Edit_Class($classname)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs']=$this->Class_model->Get_Single_Class_Detail($classname);
		  $data['blogs1'] = $this->Class_model->get_teachers_names();
          if($data)
          {
             $this->load->view('Admin/Class/Edit_Class',$data);
          }
          else
          {
          	$this->load->view('dashboard-2');
          }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Update_class_to_database()
	{
		$classname=$_POST['classname'];
    	$monthlyfee=$_POST['monthlyfee'];
    	$admissionfee=$_POST['admissionfee'];
    	$examfee=$_POST['examfee'];
    	$certificationfee=$_POST['certificationfee'];
    	$duedate=$_POST['duedate'];
    	$note=$_POST['note'];
    	$modified_at = date('Y-m-d H:i:s');
        $data = $this->Class_model->update_class($classname, $monthlyfee, $admissionfee, $examfee, $certificationfee, $duedate, $note, $modified_at);
		if($data)
		{
			$this->load->library('session');
        	$this->session->set_flashdata('msg1', 'Category added');
            redirect('Class_Controller/class_page');
		}else
		{	
		  redirect('Admin_Controller/index');
		}
	} 
	public function Delete_Class($classname)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data=$this->Class_model->Delete_Class($classname);
          if($data)
		  {
             $this->load->library('session');
        	 $this->session->set_flashdata('msg', 'Category added');
             redirect('Class_Controller/class_page');
	   	  }
		  else
	   	  {
             $this->load->view('dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
       
	}

}