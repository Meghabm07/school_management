<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Section_Controller extends CI_Controller {

    function __construct()
    { 
		parent::__construct();
		$this->load->model('Authentication_model');
		$this->load->model('Section_model');
    }
    public function Section_page()
	{
      $this->load->library('session');
		if($this->session->userdata('user'))
		{
            $data['blogs'] = $this->Section_model->get_Sections_details();
            $this->load->view('Admin/Sections/Section_page',$data);
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Add_Section()
	{
      $this->load->library('session');
		if($this->session->userdata('user'))
		{
			$data['blogs'] = $this->Section_model->get_class_names();
			 $data['blogs1'] = $this->Section_model->get_teachers_names();
            $this->load->view('Admin/Sections/Add_Sections',$data);
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Add_section_to_database()
	{
		$Sectionname=$_POST['Section'];
    	$class=$_POST['class'];
    	$verify = $this->Section_model->check_section_already_exits($Sectionname,$class);
    	if($verify)
    	{
    	   $teachername=$_POST['teachername'];
    	   $description=$_POST['description'];
    	   $created_at = date('Y-m-d H:i:s');
           $data = $this->Section_model->Add_Sections($Sectionname, $class, $teachername, $description, $created_at);
           if($data)
		   {
		   	  $this->load->library('session');
        	  $this->session->set_flashdata('msg', 'Category added');
              redirect('Section_Controller/Section_page');
			  $this->Section_page();
		   }else
		   {	 
		     redirect('admin_Controller/index');
		   }
		}
		 else
		 {
        	$this->load->library('session');
        	$this->session->set_flashdata('msg', 'Category added');
            redirect('Section_Controller/Add_Section');
        	
        }

    }
    public function Edit_Section($v1,$v2)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $section =  $this->uri->segment(3);
          $classname =  $this->uri->segment(4);
		  $data['blogs'] = $this->Section_model->get_single_Section_details($section,$classname);
		  $data['blogs1'] = $this->Section_model->get_teachers_details();
          if($data)
		  {
             $this->load->view('Admin/Sections/Edit_Sections',$data);
	   	  }
		  else
	   	  {
             $this->load->view('dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Update_section_to_database($v1,$v2)
	{
		$section =  $this->uri->segment(3);
        $classname =  $this->uri->segment(4);
    	$teachername=$_POST['teachername'];
    	$description=$_POST['description'];
    	$modified_at = date('Y-m-d H:i:s');
        $data = $this->Section_model->update_Sections($section, $classname, $teachername, $description, $modified_at);
           if($data)
		   {
			  $this->load->library('session');
        	  $this->session->set_flashdata('msg1', 'Category added');
              redirect('Section_Controller/Section_page');
		   }else
		   {	
		     redirect('admin_Controller/index');
		   }

    }
	public function Delete_Section($v1,$v2)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $section =  $this->uri->segment(3);
          $classname =  $this->uri->segment(4);
		  $data=$this->Section_model->Delete_Section($classname,$section);
          if($data)
		  {
              $this->load->library('session');
        	  $this->session->set_flashdata('msg2', 'Category added');
              redirect('Section_Controller/Section_page');
	   	  }
		  else
	   	  {
             $this->load->view('Admin/dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
       
	}
}