<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher_Controller extends CI_Controller {

    function __construct()
    { 
		parent::__construct();
		$this->load->model('Authentication_model');
		$this->load->model('Teacher_model');
    }
	public function Teachers_page()
	{
    $this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs'] = $this->Teacher_model->get_teachers_details();
		  if($data)
		  {
            $this->load->view('Admin/Teachers/Teachers_page',$data);
          } 
          else
          {
            $this->load->view('dashboard-2');
          }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
  public function teacher_attendence()
  {
    $this->load->library('session');
    if($this->session->userdata('user'))
    {
      $data['blogs'] = $this->Teacher_model->get_teachers_details();
      if($data)
      {
            $this->load->view('Admin/Teachers/Teachers_attendence',$data);
          } 
          else
          {
            $this->load->view('dashboard-2');
          }
        }
    else{
      redirect('Authentication_Controller/index');
    }
  }
   public function Find_Teachers_for_attendance()
  { 
    $this->load->library('session');
    if($this->session->userdata('user'))
    {
      $attendencedate1=$_POST['attendencedate1'];
      $data['attendencedate']=$attendencedate1;
      $data['blogs'] = $this->Teacher_model->get_teachers_details();
      if($data)
      {

         $this->load->view('Admin/Teachers/index_attendance',$data);
      }
      else
      {
        $this->load->view('dashboard-2');
      }
    }
    else
    {
      redirect('Authentication_Controller/index');
    }
  }
   public function Add_attendence_to_database()
  { 
         $status=$_POST['status'];
         $teachername = $_POST['teachername'];
         echo $teachername;
         $phonenumber = $_POST['phonenumber'];
         $email = $_POST['email']; 
         $attendencedate = $_POST['attendencedate'];
         if ($status == "P")
         {
           $present = "P";
           $absent = 0;
           $verify = $this->Teacher_model->check_for_attendence_is_already_marked($teachername, $phonenumber, $email, $attendencedate);
           if($verify)
           {
              $data = $this->Teacher_model->update_attendence_to_database($teachername, $phonenumber, $email, $attendencedate, $present, $absent);
           }
           else
           {
              $data = $this->Teacher_model->Add_attendence_to_database($teachername, $phonenumber, $email, $attendencedate, $present, $absent);
           }
        }
        else
        {
          $present = 0;
           $absent = "A";
           $verify = $this->Teacher_model->check_for_attendence_is_already_marked($teachername, $phonenumber, $email, $attendencedate);
           if($verify)
           {
              $data = $this->Teacher_model->update_attendence_to_database($teachername, $phonenumber, $email, $attendencedate, $present, $absent);
           }
           else
           {
              $data = $this->Teacher_model->Add_attendence_to_database($teachername, $phonenumber, $email, $attendencedate, $present, $absent);
           }
        }
       
  }
    public function View_Teacher($teachername)
    {
        $this->load->library('session');
        if($this->session->userdata('user'))
        {
          $data['blogs'] = $this->Teacher_model->get_single_teachers_details($teachername);
          if($data)
          {
            $this->load->view('Admin/Teachers/View_single_teacher',$data);
          } 
          else
          {
            $this->load->view('dashboard-2');
          }
        }
        else{
            redirect('Authentication_Controller/index');
        }
    }
	public function Add_Teacher()
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
          $this->load->view('Admin/Teachers/Add_teachers');
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}	
	public function Add_Teacher_to_database()
	{
		$teachername=$_POST['teachername'];
    	$subject=$_POST['subject'];
    	$phonenumber=$_POST['phonenumber'];
    	$presentadd=$_POST['presentadd'];
    	$permanentadd=$_POST['permanentadd'];
    	$gender=$_POST['gender'];
    	$bloodgroup=$_POST['bloodgroup'];
    	$religion=$_POST['religion'];
    	$dob=$_POST['dob'];
    	$joiningdate=$_POST['joiningdate'];
    	$role=$_POST['role'];
    	$salary=$_POST['salary'];
    	$salarytype=$_POST['salarytype'];
    	$email=$_POST['email'];
    	$teacherpassword=$_POST['teacherpassword'];
    	$fb=$_POST['fb'];
    	$twt=$_POST['twt'];
    	$linkedin=$_POST['linkedin'];
    	$insta=$_POST['insta'];
    	$description=$_POST['description'];
    	$created_at = date('Y-m-d H:i:s');
    	$config['upload_path'] = 'teachersphoto/';
		$config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $_FILES['file']['name'];
        $this->load->library('upload', $config);
        $this->upload->initialize($config);//not neccessary 
        if($this->upload->do_upload('file'))
        {
            $uploadData = $this->upload->data();
            $file = $uploadData['file_name'];
        }
        else
        {
            $file = '';
        }
        $data = $this->Teacher_model->add_teacher($teachername, $subject, $phonenumber, $presentadd, $permanentadd, $gender, $bloodgroup, $religion, $dob, $joiningdate, $role,  $salarytype, $salary, $email, $teacherpassword, $fb, $twt, $insta, $linkedin, $description, $file, $created_at);
		if($data)
		{
      $this->load->library('session');
      $this->session->set_flashdata('msg', 'Category added');
      redirect('Teacher_Controller/Teachers_page');
		}else
		{	
		  redirect('admin_Controller/index');
		}
	}
	public function Edit_Teacher($teachername)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs']=$this->Teacher_model->Get_Single_Teacher_Detail($teachername);
          if($data)
          {
             $this->load->view('Admin/Teachers/Edit_Teacher',$data);
          }
          else
          {
          	$this->load->view('dashboard-2');
          }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Update_Teacher_to_database()
	{
		$teachername=$_POST['teachername'];
    	$subject=$_POST['subject'];
    	$phonenumber=$_POST['phonenumber'];
    	$presentadd=$_POST['presentadd'];
    	$permanentadd=$_POST['permanentadd'];
    	$gender=$_POST['gender'];
    	$bloodgroup=$_POST['bloodgroup'];
    	$religion=$_POST['religion'];
    	$dob=$_POST['dob'];
    	$joiningdate=$_POST['joiningdate'];
    	$role=$_POST['role'];
    	$salary=$_POST['salary'];
    	$salarytype=$_POST['salarytype'];
    	$email=$_POST['email'];
    	$teacherpassword=$_POST['teacherpassword'];
    	$fb=$_POST['fb'];
    	$twt=$_POST['twt'];
    	$linkedin=$_POST['linkedin'];
    	$insta=$_POST['insta'];
    	$description=$_POST['description'];
    	$created_at = date('Y-m-d H:i:s');
    	$config['upload_path'] = 'teachersphoto/';
		$config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $_FILES['file']['name'];
        $this->load->library('upload', $config);
        $this->upload->initialize($config);//not neccessary 
        if($this->upload->do_upload('file'))
        {
            $uploadData = $this->upload->data();
            $file = $uploadData['file_name'];
        }
        else
        {
            $file = '';
        }
        $data = $this->Teacher_model->update_teacher($teachername, $subject, $phonenumber, $presentadd, $permanentadd, $gender, $bloodgroup, $religion, $dob, $joiningdate, $role,  $salarytype, $salary, $email, $teacherpassword, $fb, $twt, $insta, $linkedin, $description, $file, $created_at);
		if($data)
		{
			$this->load->library('session');
      $this->session->set_flashdata('msg1', 'Category added');
      redirect('Teacher_Controller/Teachers_page');
		}else
		{	
		  redirect('admin_Controller/index');
		}
	}
	public function Delete_Teacher($teachername)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data=$this->Teacher_model->Delete_Teacher($teachername);
      if($data)
		  {
          $this->load->library('session');
          $this->session->set_flashdata('msg2', 'Category added');
          redirect('Teacher_Controller/Teachers_page');
	   	}
		  else
	   	{
          $this->load->view('dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
       
	}
}