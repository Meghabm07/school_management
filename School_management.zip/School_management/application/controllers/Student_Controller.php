<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Student_Controller extends CI_Controller {

    function __construct()
    { 
		parent::__construct();
		$this->load->model('Authentication_model');
		$this->load->model('Student_model');
    }
   public function student_attendence() 
   {
      $this->load->library('session');
      if($this->session->userdata('user'))
      { 
        $data['blogs'] = $this->Student_model->get_students_details();
        $data['blogs1'] = $this->Student_model->get_classes_details(); 
        $this->load->view('Admin/Students/Student_attendance',$data);
      }
      else
      {
        redirect('Authentication_Controller/index');
      }
   }
    public function Find_Class_for_attendance()
  { 
    $this->load->library('session');
    if($this->session->userdata('user'))
    {
      $classname=$_POST['classname'];
      $section=$_POST['section'];
      $attendencedate1=$_POST['attendencedate1'];
      $data['attendencedate']=$attendencedate1;
      $data['section'] = $section;
      $data['classname'] = $classname;
      $data['blogs'] = $this->Student_model->get_single_classes_details($classname,$section);
      $data['blogs1'] = $this->Student_model->get_classes_details(); 
      if($data)
      {

         $this->load->view('Admin/Students/index_attendance',$data);
      }
      else
      {
        $this->load->view('dashboard-2');
      }
    }
    else
    {
      redirect('Authentication_Controller/index');
    }
  }
  public function Add_attendence_to_database()
  { 
         $status=$_POST['status'];
         $rollno = $_POST['rollno'];
         $studentname = $_POST['studentname'];
         $parentname = $_POST['parentname'];
         $classname = $_POST['classname'];
         $sectionname = $_POST['sectionname'];
         $attendencedate = $_POST['attendencedate'];
         if ($status == "P")
         {
           $present = "P";
           $absent = 0;
           $verify = $this->Student_model->check_for_attendence_is_aleready_marked($rollno, $classname, $studentname, $sectionname, $attendencedate);
           if($verify)
           {
              $data = $this->Student_model->update_attendence_to_database($rollno, $classname, $studentname, $parentname, $sectionname, $attendencedate, $present, $absent);
           }
           else
           {
              $data = $this->Student_model->Add_attendence_to_database($rollno, $classname, $studentname, $parentname, $sectionname, $attendencedate, $present, $absent);
           }
        }
        else
        {
          $present = 0;
           $absent = "A";
           $verify = $this->Student_model->check_for_attendence_is_aleready_marked($rollno, $classname, $studentname, $sectionname, $attendencedate);
           if($verify)
           {
              $data = $this->Student_model->update_attendence_to_database($rollno, $classname, $studentname, $parentname, $sectionname, $attendencedate, $present, $absent);
           }
           else
           {
              $data = $this->Student_model->Add_attendence_to_database($rollno, $classname, $studentname, $parentname, $sectionname, $attendencedate, $present, $absent);
           }
        }
       
  }
	public function view_students() 
	{
    $this->load->library('session');
		if($this->session->userdata('user'))
		{  
            $data['blogs'] = $this->Student_model->get_students_details();
            $data['blogs1'] = $this->Student_model->get_classes_details(); 
            $this->load->view('Admin/Students/view_students',$data);
    }
		else{
			redirect('Authentication_Controller/index');
		}
	}
  public function View_Single_Student($rollno)
  {
    $this->load->library('session');
    if($this->session->userdata('user'))
    { 
            $data['blogs'] = $this->Student_model->get_single_students_details($rollno);
            $this->load->view('Admin/Students/View_Single_Student',$data);
        }
    else{
      redirect('Authentication_Controller/index');
    }
  }
	public function Find_Class()
	{
      $this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $classname=$_POST['classname'];
		  $section=$_POST['section'];
      $data['blogs1'] = $this->Student_model->get_classes_details(); 
		  $data['blogs'] = $this->Student_model->get_single_classes_details($classname,$section);
		  if($data)
		  {
            $this->load->view('Admin/Students/index',$data);
          }
          else
          {
            $this->load->view('dashboard-2');
          }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function student_admission()
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
          $data['blogs'] = $this->Student_model->get_classes_details(); 
          $this->load->view('Admin/Students/student_admission',$data);
    }
		else
    {
			redirect('Authentication_Controller/index');
		}
	}
    public function parents_page()
    { 
      $this->load->library('session');
        if($this->session->userdata('user'))
        {
          $data['blogs'] = $this->Student_model->get_parents_details();
          if($data)
          {
            $this->load->view('Admin/Students/parents_page',$data);
          }
          else
          {
            $this->load->view('dashboard-2');
          }
        }
        else{
            redirect('Authentication_Controller/index');
        }
    }

  public function fetch_section()
   {
     $classname = $this->input->post('classname');
     $section = $this->input->post('section');
     if($classname)
     {
       echo $this->Student_model->fetch_section($classname,$section);
     }
  }
 


	public function Add_students_to_database()
	{
		$studentname=$_POST['studentname'];
    	$parentname=$_POST['parentname'];
    	$dob=$_POST['dob'];
    	$gender=$_POST['gender'];
    	$phonenumber=$_POST['phonenumber'];
    	$presentadd=$_POST['presentadd'];
    	$permanentadd=$_POST['permanentadd'];
    	$religion=$_POST['religion'];
    	$studentemail=$_POST['studentemail'];
    	$parentemail=$_POST['parentemail'];
    	$section=$_POST['section'];
    	$config['upload_path'] = 'studentsphoto/';
		   $config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $_FILES['file']['name'];
        $this->load->library('upload', $config);
        $this->upload->initialize($config);//not neccessary 
        if($this->upload->do_upload('file'))
        {
            $uploadData = $this->upload->data();
            $file = $uploadData['file_name'];
        }
        else
        {
            $file = '';
        }
    	$studentpassword=$_POST['studentpassword'];
    	$parentpassword=$_POST['parentpassword'];
    	$bloodgroup=$_POST['bloodgroup'];
    	$admissiondate=$_POST['admissiondate'];
    	$class=$_POST['classname'];
    	$section=$_POST['section'];
       	$description=$_POST['description'];
    	$created_at = date('Y-m-d H:i:s');
    	$query = $this->Student_model->Student_Name_Validation($studentname,$parentname);
        if($query)
        {
            $data = $this->Student_model->add_students($studentname, $parentname, $dob, $gender, $phonenumber, $presentadd, $permanentadd, $religion, $studentemail, $parentemail, $file, $studentpassword, $parentpassword,  $bloodgroup, $admissiondate, $class, $section, $description, $created_at);
           if($data)
		      {
            $this->load->library('session');
            $this->session->set_flashdata('msg', 'Category added');
            redirect('Student_Controller/view_students');
		      }
          else
		      {	
		         redirect('admin_Controller/index');
		      }

        }
        else{
        	$this->load->library('session');
        	$this->session->set_flashdata('msg', 'Category added');
            redirect('Admin_Controller/student_admission');
        	
        }
		
	}
	public function Edit_Student($rollno)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs'] = $this->Student_model->get_single_student_details($rollno);
      $data['blogs1'] = $this->Student_model->get_classes_details();
          if($data)
		  {
             $this->load->view('Admin/Students/Edit_students',$data);
	   	  }
		  else
	   	  {
             $this->load->view('dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function update_student_to_database($rollno)
	{
		$studentname=$_POST['studentname'];
    	$parentname=$_POST['parentname'];
    	$dob=$_POST['dob'];
    	$gender=$_POST['gender'];
    	$phonenumber=$_POST['phonenumber'];
    	$presentadd=$_POST['presentadd'];
    	$permanentadd=$_POST['permanentadd'];
    	$religion=$_POST['religion'];
    	$studentemail=$_POST['studentemail'];
    	$parentemail=$_POST['parentemail'];
    	$section=$_POST['section'];
    	$config['upload_path'] = 'studentsphoto/';
		$config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $_FILES['file']['name'];
        $this->load->library('upload', $config);
        $this->upload->initialize($config);//not neccessary 
        if($this->upload->do_upload('file'))
        {
            $uploadData = $this->upload->data();
            $file = $uploadData['file_name'];
        }
        else
        {
            $file = '';
        }
    	$studentpassword=$_POST['studentpassword'];
    	$parentpassword=$_POST['parentpassword'];
    	$bloodgroup=$_POST['bloodgroup'];
    	$admissiondate=$_POST['admissiondate'];
    	$class=$_POST['classname'];
    	$section=$_POST['section'];
      $description=$_POST['description'];
    	$created_at = date('Y-m-d H:i:s');
        $data = $this->Student_model->update_student($rollno, $studentname, $parentname, $dob, $gender, $phonenumber, $presentadd, $permanentadd, $religion, $studentemail, $parentemail, $file, $studentpassword, $parentpassword,  $bloodgroup, $admissiondate, $class, $section, $description, $created_at);
		  if($data)
		  {
			  $this->load->library('session');
        $this->session->set_flashdata('msg1', 'Category added');
        redirect('Student_Controller/view_students');
	  	}
      else
		  {	
		    redirect('admin_Controller/index');
		  }
	}
	public function Delete_Student($rollno)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data=$this->Student_model->Delete_Student($rollno);
      if($data)
		  {
            $this->load->library('session');
            $this->session->set_flashdata('msg2', 'Category added');
            redirect('Student_Controller/view_students');
	   	}
		  else
	   	{
             $this->load->view('dashboard-2');
		  }
    }
		else
    {
			redirect('Authentication_Controller/index');
		}
       
	}
}
?>