<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subject_Controller extends CI_Controller {

    function __construct()
    {
		parent::__construct(); 
		$this->load->model('Authentication_model'); 
		$this->load->model('Subject_model');
    }
    public function view_subjects()
	{ 
      $this->load->library('session');
		if($this->session->userdata('user'))
		{
            $data['blogs'] = $this->Subject_model->get_subjects_details();
            $data['blogs1'] = $this->Subject_model->get_classes_details();
            $this->load->view('Admin/Subjects/View_subjects',$data);
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Add_subjects()
	{
      $this->load->library('session');
		if($this->session->userdata('user'))
		{
 			$data['blogs'] = $this->Subject_model->get_class_details();
			$data['blogs1'] = $this->Subject_model->get_teacher_details();
            $this->load->view('Admin/Subjects/Add_subjects',$data);
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Add_subjects_to_database()
	{
		$subjectname=$_POST['subjectname'];
    	$subjectcode=$_POST['subjectcode'];
    	$subjecttype=$_POST['subjecttype'];
    	$class=$_POST['class'];
    	$teacher=$_POST['teacher'];
    	$passmarks=$_POST['passmarks'];
    	$fullmarks=$_POST['fullmarks'];
    	$description=$_POST['description'];
    	$created_at = date('Y-m-d H:i:s');
    	$query = $this->Subject_model->Subject_Name_Validation($subjectname);
        if($query)
        {
           $data = $this->Subject_model->Add_subjects($subjectname, $subjectcode, $subjecttype, $class, $teacher, $passmarks, $fullmarks, $description, $created_at);
           if($data)
		   {
		   	  $this->load->library('session');
        	  $this->session->set_flashdata('msg', 'Category added');
              redirect('Subject_Controller/view_subjects');
		   }else
		   {	
		     redirect('admin_Controller/index');
		   }
		 }
        else{
        	$this->load->library('session');
        	$this->session->set_flashdata('msg', 'Category added');
            redirect('Subject_Controller/Add_subjects');
        	
        }

    }
    public function Edit_Subject($subjectcode)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs'] = $this->Subject_model->get_single_subject_details($subjectcode);
		  $data['blogs1'] = $this->Subject_model->get_teacher_details();
		  $data['blogs2'] = $this->Subject_model->get_classes_details();
          if($data)
		  {
             $this->load->view('Admin/Subjects/Edit_subjects',$data);
	   	  }
		  else
	   	  {
             $this->load->view('dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Find_Class()
	{
      $this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $classname=$_POST['classname'];
		  $data['blogs'] = $this->Subject_model->get_single_classes_details($classname);
          $data['blogs1'] = $this->Subject_model->get_classes_details();
		  if($data)
		  {
            $this->load->view('Admin/Subjects/index',$data);
          }
          else
          {
            $this->load->view('dashboard-2');
          }
        }
		else{
			redirect('Authentication_Controller/index');
		}
	}
	public function Update_subjects_to_database($subjectname)
	{
    	$subjectcode=$_POST['subjectcode'];
    	$subjecttype=$_POST['subjecttype'];
    	$class=$_POST['class'];
    	$teacher=$_POST['teacher'];
    	$passmarks=$_POST['passmarks'];
    	$fullmarks=$_POST['fullmarks'];
    	$description=$_POST['description'];
    	$created_at = date('Y-m-d H:i:s');
        $data = $this->Subject_model->update_subjects($subjectname, $subjectcode, $subjecttype, $class, $teacher, $passmarks, $fullmarks, $description, $created_at);
           if($data)
		   {
			  $this->load->library('session');
        	  $this->session->set_flashdata('msg1', 'Category added');
              redirect('Subject_Controller/view_subjects');
		   }else
		   {	
		     redirect('admin_Controller/index');
		   }

    }
	public function Delete_Subject($subjectname)
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data=$this->Subject_model->Delete_Subject($subjectname);
          if($data)
		  {
             $this->load->library('session');
        	 $this->session->set_flashdata('msg2', 'Category added');
             redirect('Subject_Controller/view_subjects');
	   	  }
		  else
	   	  {
             $this->load->view('dashboard-2');
		  }
        }
		else{
			redirect('Authentication_Controller/index');
		}
       
	}
}
?>
