<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Controller extends CI_Controller {

    function __construct()
    {
		parent::__construct();
		$this->load->model('Authentication_model');
		$this->load->model('Admin_model');
    }
	public function index() 
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['students'] = $this->Admin_model->get_students_details();
		  $data['teachers'] = $this->Admin_model->get_teachers_details();
		  $data['classes'] = $this->Admin_model->get_classes_details();
		  $this->load->view('dashboard-2',$data);
		}
		else{
			redirect('Authentication_Controller/index');
		}
		
	}
	public function Calender()
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs']=$this->Admin_model->get_events();
          $this->load->view('Calender',$data);
		}
		else{
			redirect('Authentication_Controller/index');
		}
		
	}
    public function viewprofile()
    {
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs']=$this->Admin_model->get_admin_details();
          $this->load->view('Admin/profile',$data);
        }
		else{
			redirect('Authentication_Controller/index');
		}
		
    }
    public function editprofile()
    {
		$this->load->library('session');
		if($this->session->userdata('user'))
		{
          $this->load->view('Admin/Edit_Profile');
        }
		else{
			redirect('Authentication_Controller/index');
		}
		
    }
	public function update_profile()
	{
	    $uname=$_POST['uname'];
    	$email=$_POST['email'];
    	$phonenumber=$_POST['phonenumber'];
    	$permanentadd=$_POST['permanentadd'];
    	$presentadd=$_POST['presentadd'];
    	$designation=$_POST['designation'];
    	$gender=$_POST['gender'];
    	$bloodgroup=$_POST['bloodgroup'];
    	$religion=$_POST['religion'];
    	$dob=$_POST['dob'];
        $joiningdate = $_POST['joiningdate'];
        $description=$_POST['description'];
		$pw = $_POST['pw'];
		$hash_pass=md5($pw);
		$config['upload_path'] = 'upload/';
		$config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $_FILES['file']['name'];
        $this->load->library('upload', $config);
        $this->upload->initialize($config);//not neccessary 
        if($this->upload->do_upload('file'))
        {
            $uploadData = $this->upload->data();
            $file = $uploadData['file_name'];
        }
        else
        {
            $file = '';
        }
		$data = $this->Admin_model->update_profile($uname,$email, $phonenumber, $permanentadd, $presentadd, $designation, $gender, $bloodgroup, $religion, $dob, $joiningdate, $description, $hash_pass, $file );
		if($data)
		{
			$this->viewprofile();
		}else
		{	
		  $this->index();
		}
	}
	public function add_events() 
    {
      /* Our calendar data */
        $name = $this->input->post("title", TRUE);
        $desc = $this->input->post("description", TRUE);
        $start_date = $this->input->post("start_date", TRUE);
        $end_date = $this->input->post("end_date", TRUE);
        $this->Admin_model->add_event($name,$desc,$start_date,$end_date);
        $this->Calender();     
    }
    public function get_events()
    {
    	$this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $data['blogs']=$this->Admin_model->get_events();
          $this->load->view('Calender',$data);

        }
		else{
			redirect('Authentication_Controller/index');
		}
		
    }
    public function cancel()
	{
       $this->load->library('session');
		if($this->session->userdata('user'))
		{
		  $this->index();
		}
		else{
			redirect('Authentication_Controller/index');
		}
	}	
	
}