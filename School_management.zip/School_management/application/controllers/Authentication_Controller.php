<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication_Controller extends CI_Controller {

    function __construct()
    {
		parent::__construct();
		$this->load->model('Authentication_model');
    }
	public function index()
	{
		$this->load->view('Authentication_forms/login');
	}
	public function login(){
		//load session library
		$this->load->library('session');
		$role = $_POST['level'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		if($role == 1) 
		{
			$hash_password=md5($password);
		    $data = $this->Authentication_model->login($email, $hash_password);
		    if($data)
		    {
		      $this->session->set_userdata('user', $data);
		      $this->session->set_userdata('role',$role);
              return redirect('Admin_Controller/index' , $data);
	     	}
	    	else
		    {
			  header('location:'.base_url().$this->index());
			  $this->session->set_flashdata('error','Invalid login. User not found');
		    } 
		}
		elseif($role == 2)
		{
			$data = $this->Authentication_model->studentlogin($email, $password);
		    if($data)
		    {
		      $this->session->set_userdata('user', $data);
		      $this->session->set_userdata('role',$role);
              return redirect('Login_Students_Controller/index' , $data);
	     	}
	    	else
		    {
			  header('location:'.base_url().$this->index());
			  $this->session->set_flashdata('error','Invalid login. User not found');
		    } 
		}
		else
		{
			redirect('login');
		}
	}
	public function dashboard()
	{
		$this->load->library('session');
		if($this->session->userdata('user'))
		{		  
		    $this->load->view('dashboard-2',$data);
		}
		else{
			redirect('login');
		}
	}
	public function pageregister()
	{
		$this->load->view('Authentication_forms/register');
	}
	public function register()
	{
		$email=$_POST['email'];
    	$uname=$_POST['uname'];
    	$password=$_POST['password'];
    	$hash_password=md5($password);
		$data = $this->Authentication_model->register($email, $uname, $hash_password);
                if($data)
                {
                     $this->load->view('Authentication_forms/login'); 	
                }else
                {
                  return false;
                }
	}
	public function pagerecoverpw()
	{
		$this->load->view('Authentication_forms/recoverpw');
	}
	public function confirmmail()
	{
		$this->load->view('Authentication_forms/confirm-mail');
	}
	public function lockscreen()
	{
		$this->load->view('Authentication_forms/lockscreen');
	}
	public function logout(){
		//load session library
		$this->load->library('session');
		$this->session->unset_userdata('user');
		redirect('/');
	}
}
