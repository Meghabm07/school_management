<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Login_Students_Controller extends CI_Controller { 

    function __construct()
    {  
		parent::__construct();
		$this->load->model('Authentication_model');
		$this->load->model('Login_Students_model');
    } 
   public function index()
   {
      $this->load->library('session');
      if($data1=$this->session->userdata('user'))
      { 
        $this->load->view('Students/Profile');
      }
      else
      {
        redirect('Authentication_Controller/index');
      }
   }
   public function Edit_Profile()
   {
      $this->load->library('session');
      if($data1 = $this->session->userdata('user'))
      { 
        $this->load->view('Students/Edit_Profile');
      }
      else
      {
        redirect('Authentication_Controller/index');
      }
   }
    public function Update_Profile()
  {
    $this->load->library('session');
    if($this->session->userdata('user'))
    {
      $studentname=$this->uri->segment(3);;
      $rollno=$this->uri->segment(4);
      $newpassword=$_POST['confirmpassword'];
      $config['upload_path'] = 'studentsphoto/';
      $config['allowed_types'] = 'jpg|jpeg|png';
      $config['file_name'] = $_FILES['file']['name'];
      $this->load->library('upload', $config);
      $this->upload->initialize($config);//not neccessary 
      if($this->upload->do_upload('file'))
      {
          $uploadData = $this->upload->data();
          $file = $uploadData['file_name'];
      }
      else
      {
          $file = '';
      }
      $data = $this->Login_Students_model->Update_Profile($studentname,$rollno,$newpassword,$file);
      if($data)
      {
         $this->index();
      }
    }
    else
    {
      redirect('Authentication_Controller/index');
    }
  }
  public function Attendence()
   {
      $this->load->library('session');
      if($data1 = $this->session->userdata('user'))
      { 
        $studentname = $data1['studentname'];
        $parentname = $data1['parentname'];
        $classname = $data1['classname'];
        $section = $data1['section'];
        $rollno = $data1['rollno'];
        $data['blogs'] = $this->Login_Students_model->get_attendence_present_details($studentname, $parentname, $classname, $section, $rollno);
        $data['blogs1'] = $this->Login_Students_model->get_attendence_absent_details($studentname, $parentname, $classname, $section, $rollno);
        if ($data) 
        {
           $this->load->view('Students/Attendence',$data);
        }
        else
        {
           $this->index();
        }
      }
      else
      {
        redirect('Authentication_Controller/index');
      }
   }
   public function Class1()
   {
      $this->load->library('session');
      if($data1 = $this->session->userdata('user'))
      { 
        $classname = $data1['classname'];
        $section = $data1['section'];
        $data['blogs'] = $this->Login_Students_model->get_Class_details($classname, $section);
        if ($data) 
        {
           $this->load->view('Students/Class',$data);
        }
        else
        {
           $this->index();
        }
      }
      else
      {
        redirect('Authentication_Controller/index');
      }
   }
   public function Subjects()
   {
      $this->load->library('session');
      if($data1 = $this->session->userdata('user'))
      { 
        $classname = $data1['classname'];
        $data['blogs'] = $this->Login_Students_model->get_Subject_details($classname);
        if ($data) 
        {
           $this->load->view('Students/Subjects',$data);
        }
        else
        {
           $this->index();
        }
      }
      else
      {
        redirect('Authentication_Controller/index');
      }
   }
   public function Teachers()
   {
      $this->load->library('session');
      if($data1 = $this->session->userdata('user'))
      { 
        $classname = $data1['classname'];
        $data['blogs'] = $this->Login_Students_model->get_Teachers_details($classname);
        if ($data) 
        {
           $this->load->view('Students/Teachers',$data);
        }
        else
        {
           $this->index();
        }
      }
      else
      {
        redirect('Authentication_Controller/index');
      }
   }
   public function Time_Table()
   {
      $this->load->library('session');
      if($data1 = $this->session->userdata('user'))
      { 
        $classname = $data1['classname'];
        $sectionname = $data1['section'];
        $data['blogs'] = $this->Login_Students_model->get_monday_timetable_details($classname,$sectionname);
        $data['blogs1'] = $this->Login_Students_model->get_tuesday_timetable_details($classname,$sectionname);
        $data['blogs2'] = $this->Login_Students_model->get_wednesday_timetable_details($classname,$sectionname);
        $data['blogs3'] = $this->Login_Students_model->get_thursday_timetable_details($classname,$sectionname);
        $data['blogs4'] = $this->Login_Students_model->get_friday_timetable_details($classname,$sectionname);
        $data['blogs5'] = $this->Login_Students_model->get_saturday_timetable_details($classname,$sectionname);
        if ($data) 
        {
           $this->load->view('Students/Timetable',$data);
        }
        else
        {
           $this->index();
        }
      }
      else
      {
        redirect('Authentication_Controller/index');
      }
   }
  public function logout()
  {
    //load session library
    $this->load->library('session');
    $this->session->unset_userdata('user');
    redirect('/');
  }
}
?>